/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package file;

import calendar.Shift;
import calendar.TypeJob;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import schedule.Schedule;
import schedule.SolutionBB;
import schedule.SolutionH;



/**
 *
 * @author Tatiana
 */
public class WriteSolution {
    
    /* Write the solution of Branch & Bound */
    public WriteSolution(Schedule sch, SolutionBB solBB, boolean withOrder){
        
        try {
            String typeOrder = "co";
            if(!withOrder) typeOrder = "so";
            
            String solName = sch.instName.replaceFirst("I", "S").replace(".txt","__BBT"+typeOrder+".txt");
            
            BufferedWriter bw = new BufferedWriter(new FileWriter(sch.solPath+solName));
            
            //Comments between "### ###"
            
            //Cost per soft constraint
            bw.write("### Cost per Soft Constraint: Index;Weight;Cost ###\n");
            for(int i=1; i<=solBB.noSoftC; i++){
                bw.write("### S"+i+";"+solBB.weightSC[i]+";"+solBB.best_costSC[i]+" ###\n");
            }
            bw.write("### Total cost: "+solBB.bestCost+" ###\n");
            
            bw.write("### Summary Information: "+solBB.bestCost+";"+solBB.runTime+" ###\n");
            
            //Assignments
            bw.write("### Month/Year: "+sch.month+"/"+sch.year+" ###\n");
            bw.write("### Format: Physician;Area;Day;Shift ###\n");
            
            for(int iPhys=1; iPhys<=sch.noPhys; iPhys++){
                for(int iDay=1; iDay<=sch.noDays; iDay++){
                    TypeJob job = solBB.best_assignJob[iPhys][iDay];
                    
                    if(job.shift != Shift.OFF){
                        String aux_physician = "Physician"+iPhys;
                        String aux_location = "Location"+job.loc;
                        String aux_day = Integer.toString(iDay);
                        
                        if(job.shift == Shift.MOR || job.shift == Shift.DAY){
                            bw.write(aux_physician+";"+aux_location+";"+aux_day+";M\n");
                        }
                        if(job.shift == Shift.AFT || job.shift == Shift.DAY){
                            bw.write(aux_physician+";"+aux_location+";"+aux_day+";T\n");
                        }
                        if(job.shift == Shift.NIG){
                            bw.write(aux_physician+";"+aux_location+";"+aux_day+";N\n");
                        }
                    }
                }
            }
            
            bw.close();
        } catch (IOException ex) {
            Logger.getLogger(WriteSolution.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
    /* Write the solution of Local Search */
    public WriteSolution(Schedule sch, SolutionH solH, boolean withOrder, int exec){
        
        try {
            String initial = "co";
            if(!withOrder) initial = "so";
            String solName = sch.instName.replaceFirst("I", "S").replace(".txt","__FM"+initial+"_"+exec+".txt");
            
            BufferedWriter bw = new BufferedWriter(new FileWriter(sch.solPath+solName));
            
            //Comments between "### ###"
            
            //Cost per soft constraint
            bw.write("### Cost per Soft Constraint: Index;Weight;Cost ###\n");
            for(int i=1; i<=solH.noSoftC; i++){
                bw.write("### S"+i+";"+solH.weightSC[i]+";"+solH.best_costSC[i]+" ###\n");
            }
            bw.write("### Total cost: "+solH.bestCost+" ###\n");
            
            bw.write("### Summary Information: "+solH.bestCost+";"+solH.runTime+" ###\n");
            
            //Assignments
            bw.write("### Month/Year: "+sch.month+"/"+sch.year+" ###\n");
            bw.write("### Format: Physician;Area;Day;Shift ###\n");
            
            for(int iPhys=1; iPhys<=sch.noPhys; iPhys++){
                for(int iDay=1; iDay<=sch.noDays; iDay++){
                    TypeJob job = solH.best_assignJob[iPhys][iDay];
                    if(job.shift != Shift.OFF){
                        String aux_physician = "Physician"+iPhys;
                        String aux_location = "Location"+job.loc;
                        String aux_day = Integer.toString(iDay);
                        
                        if(job.shift == Shift.MOR || job.shift == Shift.DAY){
                            bw.write(aux_physician+";"+aux_location+";"+aux_day+";M\n");
                        }
                        if(job.shift == Shift.AFT || job.shift == Shift.DAY){
                            bw.write(aux_physician+";"+aux_location+";"+aux_day+";T\n");
                        }
                        if(job.shift == Shift.NIG){
                            bw.write(aux_physician+";"+aux_location+";"+aux_day+";N\n");
                        }
                    }
                }
            }
            
            bw.close();
        } catch (IOException ex) {
            Logger.getLogger(WriteSolution.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
    /* Write the solution of Heuristic */
    public WriteSolution(Schedule sch, SolutionH solH, String type, boolean withOrder, boolean withBL, int exec){
        
        try {
            String solName = sch.instName.replaceFirst("I", "S").replace(".txt","__"+type+"_"+exec+".txt");
            
            BufferedWriter bw = new BufferedWriter(new FileWriter(sch.solPath+solName));
            
            //Comments between "### ###"
            
            //Cost per soft constraint
            bw.write("### Cost per Soft Constraint: Index;Weight;Cost ###\n");
            for(int i=1; i<=solH.noSoftC; i++){
                bw.write("### S"+i+";"+solH.weightSC[i]+";"+solH.best_costSC[i]+" ###\n");
            }
            bw.write("### Total cost: "+solH.bestCost+" ###\n");
            
            bw.write("### Summary Information: "+solH.bestCost+";"+solH.runTime+" ###\n");
            
            //Assignments
            bw.write("### Month/Year: "+sch.month+"/"+sch.year+" ###\n");
            bw.write("### Format: Physician;Area;Day;Shift ###\n");
            
            for(int iPhys=1; iPhys<=sch.noPhys; iPhys++){
                for(int iDay=1; iDay<=sch.noDays; iDay++){
                    TypeJob job = solH.best_assignJob[iPhys][iDay];
                    if(job.shift != Shift.OFF){
                        String aux_physician = "Physician"+iPhys;
                        String aux_location = "Location"+job.loc;
                        String aux_day = Integer.toString(iDay);
                        
                        if(job.shift == Shift.MOR || job.shift == Shift.DAY){
                            bw.write(aux_physician+";"+aux_location+";"+aux_day+";M\n");
                        }
                        if(job.shift == Shift.AFT || job.shift == Shift.DAY){
                            bw.write(aux_physician+";"+aux_location+";"+aux_day+";T\n");
                        }
                        if(job.shift == Shift.NIG){
                            bw.write(aux_physician+";"+aux_location+";"+aux_day+";N\n");
                        }
                    }
                }
            }
            
            bw.close();
        } catch (IOException ex) {
            Logger.getLogger(WriteSolution.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }

}
