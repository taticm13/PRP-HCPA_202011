/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package file;


import calendar.TypeJob;
import calendar.DayMonth;
import calendar.WeekDay;
import calendar.Shift;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Calendar;
import java.util.logging.Level;
import java.util.logging.Logger;
import schedule.Physician;
import schedule.Schedule;

/**
 * 
 * @author Tatiana
 */

public class BuildInstance {
    
    private Schedule sch;
    
    public BuildInstance(Schedule infoSch){
        sch = infoSch;        
        readFile();        
    }
    
    private void readFile(){
        try {
            BufferedReader br = new BufferedReader(new FileReader(sch.instPath+sch.instName));            
            String linha;
            
            //Realiza a leitura por linha do arquivo
            while((linha = br.readLine())!=null){
                if(linha.startsWith("MONTH")){
                    build_monthDays(linha);
                }
                else if(linha.startsWith("HOLIDAYS")){
                    build_holidays(linha,br);
                }
                else if(linha.startsWith("LOCATIONS")){
                    build_locations(linha,br);
                }
                else if(linha.startsWith("PHYSICIANS")){
                    build_physicians(linha,br);
                }
                else if(linha.startsWith("FIXED ASSIGNMENTS")){
                    build_fixedAssigns(linha,br);
                }
                else if(linha.startsWith("LOCKS")){
                    build_locks(linha,br);
                }
                else if(linha.startsWith("NOT PREFERENCE PER LOCATION")){
                    build_notPrefLoc(linha,br);
                }
                else if(linha.startsWith("PENALTY PER ASSIGN")){
                    build_penaltyPerAssign(linha,br);
                }
                else if(linha.startsWith("REQUIREMENTS")){
                    build_requirements(linha,br);
                }
            }
                        
            build_allowPreProc();
            
            br.close();
            
        } catch (FileNotFoundException ex) {
            Logger.getLogger(BuildInstance.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(BuildInstance.class.getName()).log(Level.SEVERE, null, ex);
        }   
    }
    
    private void build_monthDays(String linha){
        sch.year        = Integer.parseInt(linha.split(" = ")[1].split(" ")[0]);
        sch.month       = Integer.parseInt(linha.split(" = ")[1].split(" ")[1]);
                            
        Calendar calendar = Calendar.getInstance();
            calendar.set(Calendar.YEAR,sch.year);
            calendar.set(Calendar.MONTH,sch.month-1);
        
        //Number of days
        calendar.set(Calendar.DAY_OF_MONTH, calendar.getActualMaximum(Calendar.DAY_OF_MONTH));
        sch.noDays = calendar.get(Calendar.DAY_OF_MONTH);
        
        //Number of weeks
        sch.noWeeks = calendar.get(Calendar.WEEK_OF_MONTH);
        
        //Days of the month
        sch.days = new DayMonth[sch.noDays+1];
        
        boolean beginSunday = false;
        for(int dayM=1; dayM<=sch.noDays; dayM++){
            calendar.set(Calendar.DAY_OF_MONTH,dayM);
            
            int iDayW = calendar.get(Calendar.DAY_OF_WEEK) - 1;
            int iWeek = calendar.get(Calendar.WEEK_OF_MONTH);
            if(beginSunday) iWeek++;
            
            //Quando domingo, atribui para semana anterior
            if(iDayW <= 0){
                iDayW = 7;
                iWeek--;
                if(iWeek == 0){
                    beginSunday = true;
                    iWeek++;
                }
            }
            
            WeekDay dayWeek = WeekDay.values()[iDayW-1];
            
            sch.days[dayM] = new DayMonth(dayM,dayWeek,iWeek);
        }
    }
    
    private void build_holidays(String linha, BufferedReader br) throws IOException{
        int qtde = Integer.parseInt(linha.split("=")[1].trim());
        
        for(int i=1; i<=qtde; i++){            
            int dayM = Integer.parseInt(br.readLine());
            
            sch.days[dayM].isHoliday = true;
            sch.days[dayM].isWorkDay = false;
        }
    } 
    
    private void build_locations(String linha, BufferedReader br) throws IOException{
        int qtde = Integer.parseInt(linha.split("=")[1].trim());
        
        sch.noLocs = qtde;
        
        build_jobs();
    }
    
    private void build_jobs(){
        sch.noJobs = (Shift.get_qtyTypes()-1) * sch.noLocs + 1; //OFF do not combine with the locations
        sch.jobs = new TypeJob[sch.noJobs+1];
        sch.jobID = new int[Shift.values().length+1][sch.noLocs+1];
        
        int ID = 1;
        for(Shift novo : Shift.values()){
            if(novo == Shift.OFF){
                sch.jobs[ID] = new TypeJob(ID,novo,0);
                sch.jobID[novo.index][0] = ID;
                ID++;
            }
            else{
                for(int iLoc=1; iLoc<=sch.noLocs; iLoc++){
                    sch.jobs[ID] = new TypeJob(ID,novo,iLoc);
                    sch.jobID[novo.index][iLoc] = ID;
                    ID++;
                }
            }
        }
        
        sch.minAssign   = new int[sch.noDays+1][sch.noJobs+1];
        sch.maxAssign   = new int[sch.noDays+1][sch.noJobs+1];
        sch.noFixed     = new int[sch.noDays+1][sch.noJobs+1];
    }
    
    private void build_physicians(String linha, BufferedReader br) throws IOException{
        int qty = Integer.parseInt(linha.split("=")[1].trim());
        
        sch.noPhys = qty;
        sch.phys = new Physician[sch.noPhys+1];
                
        for(int i=1; i<=qty; i++){  
            linha = br.readLine();
                
            Physician novo = new Physician(sch.noDays,sch.noLocs,sch.noJobs);
            
            novo.ID = Integer.parseInt(linha.split(" ")[0]);
            novo.name = linha.split(" ")[1];
            novo.workload = Integer.parseInt(linha.split(" ")[2]);
            novo.idealHours_nWrkD = Integer.parseInt(linha.split(" ")[3]);
            
            String locs[] = linha.split(" ")[4].split(",");
            for(int j=0; j<locs.length; j++){
                novo.locAllowed[j+1] = locs[j].contains("1");
            }
            novo.locAllowed[0] = true;
            
            sch.phys[novo.ID] = novo;
        }
    }
    
    private void build_fixedAssigns(String linha, BufferedReader br) throws IOException{
        int qtde = Integer.parseInt(linha.split("=")[1].trim());
        
        for(int i=1; i<=qtde; i++){
            linha = br.readLine();
            
            int iPhys       = Integer.parseInt(linha.split(" ")[0]);
            int dayMonth    = Integer.parseInt(linha.split(" ")[1]);            
            int iShifts      = Integer.parseInt(linha.split(" ")[2]);
            int iLoc        = Integer.parseInt(linha.split(" ")[3]);
            
            Physician phys  = sch.phys[iPhys];
            if(!sch.days[dayMonth].isWorkDay && (iShifts == Shift.MOR.index || iShifts == Shift.AFT.index)){
                iShifts = Shift.DAY.index;
            }
            
            if(phys.fixedJob[dayMonth] == null) sch.noFixed[dayMonth][sch.jobID[iShifts][iLoc]]++;
            phys.fixedJob[dayMonth] = sch.jobs[sch.jobID[iShifts][iLoc]];            
        }
    }
    
    private void build_locks(String linha, BufferedReader br) throws IOException{
        int qtde = Integer.parseInt(linha.split("=")[1].trim());
        
        for(int i=1; i<=qtde; i++){
            linha = br.readLine();
            
            int iPhys       = Integer.parseInt(linha.split(" ")[0]);
            int dayMonth    = Integer.parseInt(linha.split(" ")[1]);
            int shift       = Integer.parseInt(linha.split(" ")[2]);
            
            Physician phys  = sch.phys[iPhys];
            
            if(shift != Shift.OFF.index){
                phys.isLock[dayMonth][shift] = true;
                
                if(sch.days[dayMonth].isWorkDay){
                    phys.isLock[dayMonth][Shift.DAY.index] = true;
                }
                else{
                    phys.isLock[dayMonth][Shift.DAY.index] = phys.isLock[dayMonth][Shift.MOR.index] || phys.isLock[dayMonth][Shift.AFT.index];
                }
            }            
        }
    }
    
    private void build_notPrefLoc(String linha, BufferedReader br) throws IOException{
        int qtde = Integer.parseInt(linha.split("=")[1].trim());
        
        for(int i=1; i<=qtde; i++){
            linha = br.readLine();
            
            int iPhys = Integer.parseInt(linha.split(" ")[0]);
            int iLoc = Integer.parseInt(linha.split(" ")[1]);
            
            Physician phys = sch.phys[iPhys];            
            phys.locNonPref[iLoc] = true;
        }
    }
    
    private void build_penaltyPerAssign(String linha, BufferedReader br) throws IOException{
        int qtde = Integer.parseInt(linha.split("=")[1].trim());
        
        for(int i=1; i<=qtde; i++){
            linha = br.readLine();
            
            int iPhys   = Integer.parseInt(linha.split(" ")[0]);
            int day     = Integer.parseInt(linha.split(" ")[1]);
            int iShift  = Integer.parseInt(linha.split(" ")[2]);  
            int penalty = Integer.parseInt(linha.split(" ")[3]);
            
            Physician phys = sch.phys[iPhys];
            phys.penaltyAssign[day][iShift] = penalty;
            
            phys.penaltyAssign[day][Shift.DAY.index] = phys.penaltyAssign[day][Shift.MOR.index] + phys.penaltyAssign[day][Shift.AFT.index];
        }
    }
    
    private void build_requirements(String linha, BufferedReader br) throws IOException{

        for(int iDay=1; iDay<=sch.noDays; iDay++){
            for(int iJob=1; iJob<=sch.noJobs; iJob++){
                sch.maxAssign[iDay][iJob] = -1;
            }
        }
        
        while((linha = br.readLine())!=null && !linha.isEmpty()){
            
            int dayMonth    = Integer.parseInt(linha.split(" ")[0]);
            int iShifts     = Integer.parseInt(linha.split(" ")[1]);
            int iLoc        = Integer.parseInt(linha.split(" ")[2]);
            
            if(!sch.days[dayMonth].isWorkDay && (iShifts == Shift.MOR.index || iShifts == Shift.AFT.index)){
                iShifts = Shift.DAY.index;
                
                sch.minAssign[dayMonth][sch.jobID[iShifts][iLoc]] = 
                    Math.max(Integer.parseInt(linha.split(" ")[3]),sch.minAssign[dayMonth][sch.jobID[iShifts][iLoc]]);
                
                if(sch.maxAssign[dayMonth][sch.jobID[iShifts][iLoc]] != -1){
                    sch.maxAssign[dayMonth][sch.jobID[iShifts][iLoc]] = 
                        Math.min(Integer.parseInt(linha.split(" ")[4]),sch.maxAssign[dayMonth][sch.jobID[iShifts][iLoc]]);
                }
                else sch.maxAssign[dayMonth][sch.jobID[iShifts][iLoc]] = Integer.parseInt(linha.split(" ")[4]);
            }
            else{
                sch.minAssign[dayMonth][sch.jobID[iShifts][iLoc]] = Integer.parseInt(linha.split(" ")[3]);
                sch.maxAssign[dayMonth][sch.jobID[iShifts][iLoc]] = Integer.parseInt(linha.split(" ")[4]);
            }
        }
        
        //Update the OFF job
        for(int iDay=1; iDay<=sch.noDays; iDay++){
            sch.minAssign[iDay][sch.jobID[Shift.OFF.index][0]] = 0;
            sch.maxAssign[iDay][sch.jobID[Shift.OFF.index][0]] = sch.noPhys;
        }
        
    }
    
    /*	Find the available jobs for the physician on each day of the month, it considering:
        - Fixed assigments
        - Locks
        This information is not changeable.  */
    private void build_allowPreProc(){
		
        for(int iPhys=1; iPhys<=sch.noPhys; iPhys++){
            Physician phys = sch.phys[iPhys];
            
            for(int iDay=1; iDay<=sch.noDays; iDay++){
                DayMonth day = sch.days[iDay];
                
                //############################################### PER SHIFT TYPE
                //SHIFT - MOR (1)
                phys.allowPreProc_shift[iDay][Shift.MOR.index] =
                        //It is a working day
                        day.isWorkDay                               
                    &&  //The physician has not lock in the current shift
                        !phys.isLock[iDay][Shift.MOR.index]
                    &&  //The physician has not fixed assignment or it has in the current shift
                        (phys.fixedJob[iDay]==null || phys.fixedJob[iDay].shift==Shift.MOR)
                    &&  //The physician has not fixed assignment in the night shift in the previous day
                        (iDay==1 || phys.fixedJob[iDay-1]==null || phys.fixedJob[iDay-1].shift!=Shift.NIG);
                    
                //SHIFT - AFT (2)
                phys.allowPreProc_shift[iDay][Shift.AFT.index] =
                        //It is a working day
                        day.isWorkDay                               
                    &&  //The physician has not lock in the current shift
                        !phys.isLock[iDay][Shift.AFT.index]
                    &&  //The physician has not fixed assignment or it has in the current shift
                        (phys.fixedJob[iDay]==null || phys.fixedJob[iDay].shift==Shift.AFT)
                    &&  //The physician has not fixed assignment in the night shift in the previous day
                        (iDay==1 || phys.fixedJob[iDay-1]==null || phys.fixedJob[iDay-1].shift!=Shift.NIG);
                            
                //SHIFT - NIG (3)
                phys.allowPreProc_shift[iDay][Shift.NIG.index] =
                        //The physician has not lock in the current shift
                        !phys.isLock[iDay][Shift.NIG.index]
                    &&  //The physician has not fixed assignment or it has in the current shift
                        (phys.fixedJob[iDay]==null || phys.fixedJob[iDay].shift==Shift.NIG)
                    &&  //The physician has not fixed assignment in the night shift in the previous day
                        (iDay==1 || phys.fixedJob[iDay-1]==null || phys.fixedJob[iDay-1].shift!=Shift.NIG)
                        //The physician has not fixed assignment in the day shifts in the next day
                    &&  (iDay==sch.noDays || phys.fixedJob[iDay+1]==null || phys.fixedJob[iDay+1].shift==Shift.NIG);
                        //The physician has not locked MOR in the next day
                    //&&  (iDay==sch.noDays || !phys.isLock[iDay+1][Shift.MOR.index]);
            
                
                //SHIFT - DAY (4)
                phys.allowPreProc_shift[iDay][Shift.DAY.index] =
                        //It is not a working day
                        !day.isWorkDay                               
                    &&  //The physician has not lock in the current shift
                        !phys.isLock[iDay][Shift.DAY.index]
                    &&  //The physician has not fixed assignment or it has in the current shift
                        (phys.fixedJob[iDay]==null || phys.fixedJob[iDay].shift==Shift.DAY)
                    &&  //The physician has not fixed assignment in the night shift in the previous day
                        (iDay==1 || phys.fixedJob[iDay-1]==null || phys.fixedJob[iDay-1].shift!=Shift.NIG);
            
                //SHIFT - OFF (5)
                phys.allowPreProc_shift[iDay][Shift.OFF.index] =
                        phys.fixedJob[iDay] == null;                    //The physician hasn't fixed assignments on the day
                
                //################################################# PER LOCATION
                phys.allowPreProc_loc[iDay][0] = true;
                for(int iLoc=1; iLoc<=sch.noLocs; iLoc++){
                    phys.allowPreProc_loc[iDay][iLoc] =
                            //The physician has authorization in the location
                            phys.locAllowed[iLoc]
                        &&  //The physician has not fixed assignment on the day OR is fixed in the location
                            (phys.fixedJob[iDay]==null || phys.fixedJob[iDay].loc==iLoc);
                }
                
                //###################################################### PER JOB
                for(int iJob=1; iJob<=sch.noJobs; iJob++){
                    TypeJob job = sch.jobs[iJob];
                    
                    phys.allowPreProc_job[iDay][iJob] =
                            //The physician has authorization in the shift of the job
                            phys.allowPreProc_shift[iDay][job.shift.index]
                            //The physician has authorization in the location of the job
                        &&  phys.allowPreProc_loc[iDay][job.loc];
                }
            }
        }
    }
	
}
