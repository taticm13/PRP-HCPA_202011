/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package calendar;

/**
 *
 * @author Tatiana
 */
public class DayMonth {
    
    public int ID;
    public WeekDay dayWeek;
    public int week;
    
    public boolean isWorkDay;
    public boolean isWKND;
    public boolean isHoliday;
    
    public DayMonth(int infoDay, WeekDay infoDayWeek, int infoWeek){
        
        ID         = infoDay;
        dayWeek     = infoDayWeek;
        week        = infoWeek;
        
        if(dayWeek == WeekDay.SATURDAY || dayWeek == WeekDay.SUNDAY){
            isWKND = true;
            isWorkDay = false;
        }
        else{
            isWKND = false;
            isWorkDay = true;
        }
    }
}
