/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package calendar;

/**
 *
 * @author Tatiana
 */
public enum Shift {
    MOR(1),AFT(2),NIG(3),DAY(4),OFF(5);
    
    public int index;
    Shift(int index){
        this.index = index;
    }
    
    public static int get_qtyTypes(){
        return Shift.values().length;
    }
}
