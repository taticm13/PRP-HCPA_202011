/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package calendar;

/**
 *
 * @author Tatiana
 */
public class TypeJob {
    public int ID;
    
    public Shift shift;
    public int loc;
    
    public TypeJob(int infoID, Shift infoShift, int infoLoc){
        ID = infoID;
        shift = infoShift;
        loc = infoLoc;
    }
    
    public TypeJob copy(){
        return new TypeJob(ID,shift,loc);
    }
    
    /* Return TRUE if it has one of the day shifts (MOR, AFT or DAY) */
    public boolean hasDayShifts(){
        return shift==Shift.MOR || shift==Shift.AFT || shift==Shift.DAY;
    }
    
    /* Return TRUE if it has one of the night shifts (NIG) */
    public boolean hasNigShifts(){
        return shift==Shift.NIG;
    }    
    
    /* Return TRUE if is a OFF day */
    public boolean isOFF(){
        return shift==Shift.OFF;
    }
    
    /* Return the NUMBER OF WORKING HOURS in the shift */
    public int noHours(){
        if(shift==Shift.DAY || shift==Shift.NIG) return 12;
        if(shift==Shift.MOR || shift==Shift.AFT) return 6;
        else return 0;
    }
    
    /* Return the NUMBER OF SHIFTS in the grouped shift */
    public int noShifts(){
        if(shift==Shift.OFF) return 0;
        if(shift==Shift.DAY) return 2;
        else return 1;
    }
    
    /* Return TRUE if the shift is valid for the day */
    public boolean isJobValid(DayMonth day){
        if(!day.isWorkDay) return shift != Shift.MOR && shift != Shift.AFT;
        else return shift != Shift.DAY;
    }
    
    public String DEBUG(){
        return shift.name()+","+loc;
    }
}
