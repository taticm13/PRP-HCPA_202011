/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package algorithms;

import calendar.DayMonth;
import calendar.TypeJob;
import file.WriteSolution;
import schedule.Assign;
import schedule.Physician;
import schedule.Schedule;
import schedule.SolutionBB;
import schedule.SolutionH;

/**
 *
 * @author Tatiana
 */
public class VNS {
    
    public Schedule sch;
    public SolutionH solution;
    public String type = "VNS";
    public int maxComb = 50;
    
    public VNS(SolutionBB initialSol, int rep, boolean writeSol, boolean withOrder, boolean withImp){
        sch = initialSol.sch;
        solution = new SolutionH(sch,initialSol);
              
        //Improvement Phase
        if(withImp){
            solution.timeInit = System.currentTimeMillis();        
            new SI_FM(solution);
            solution.runtimeImprov = (double)(System.currentTimeMillis()-solution.timeInit)/1000;
            solution.bestCostImprov = solution.bestCost;
            if(writeSol) new WriteSolution(sch,solution,withOrder,rep);
            System.out.print(solution.bestCostImprov+";"+solution.runtimeImprov+";");
        }
        else System.out.print("-;-;");
        
        solution.timeInit   = System.currentTimeMillis();        
        double averTimeIter = 0.0;
        int maxViz          = 3;
        int kViz            = 1;
        boolean updated     = false;
        double confTime;        
        
        while(!solution.timeLimit() && solution.noIter_nImpr < solution.maxIter_nImpr){
            kViz = 1;
            
            //Stop criteria: time limit exceeded or there isn't available neighborhoods
            while(!solution.timeLimit() && kViz <= maxViz){
                solution.noIter++;                
                updated = false;
                
                confTime = System.currentTimeMillis();
                switch(kViz){
                    case 1: updated = moveCHANGE(); break;
                    case 2: updated = moveSWAP();   break;
                    case 3: updated = move3CHAIN(); break;         
                }
                averTimeIter += (double)(System.currentTimeMillis()-confTime)/1000;
                
                if(updated){
                    kViz = 1;
                    solution.noIter_nImpr = 0;
                }
                else{
                    kViz++;
                    solution.noIter_nImpr++;
                }
            }
            
            shakeCHANGE();            
        }
        
        solution.runTime = (double)(System.currentTimeMillis()-solution.timeInit)/1000;
        averTimeIter = averTimeIter/solution.noIter;
        
        if(writeSol) new WriteSolution(sch,solution,type,withOrder,withImp,rep);
        System.out.print(type+";"+solution.bestCost+";"+solution.runTime+";"+averTimeIter+";"+solution.noIter+";"+solution.noIter_nImpr+";"+solution.maxIter_nImpr);
        
    }
    
    
/*  ## CHANGE ############################################################### */
    //Without constraints
    private boolean moveCHANGE(){
        
        Assign newBest      = new Assign();
        Assign newAssign    = new Assign();
        boolean first       = true;
           
        for(int iPhys=1; iPhys<=sch.noPhys; iPhys++){
            Physician phys = sch.phys[iPhys];
            //int iDay = solution.rndSeed.nextInt(sch.noDays)+1;
            
            for(int iDay=1; iDay<=sch.noDays; iDay++){
                DayMonth day = sch.days[iDay];            
                TypeJob prevJob = solution.assignJob[iPhys][iDay];
                
                for(int iJob=1; iJob<=sch.noJobs; iJob++){
                    if(phys.allowPreProc_job[iDay][iJob] && prevJob.ID!=iJob){
                        
                        newAssign.init(phys,day,sch.jobs[iJob]);
                        newAssign.addCost = solution.verifyCost(newAssign,false);
                        
                        //Check if the cost is accepted by criteria of the heuristic                        
                        if(newAssign.addCost < 0){ 
                            if(first || newAssign.addCost < newBest.addCost){
                                first = false;
                                newBest.copy(newAssign);
                            }
                            else if(!first && newAssign.addCost == newBest.addCost && solution.rndSeed.nextInt(100) < 10){
                                newBest.copy(newAssign);
                            }
                        }
                    }
                }
            }
        }
        
        
        if(!first){
            //Update the solution with the new assignment
            solution.changeJob(newBest);            
            //solution.initCostPhys();
            
            solution.changeJob(newBest);
            
            //Update the best solution
            solution.update_bestSolution();
            
            return true;
        }
        
        return false;
    }
    
    
/*  ## SWAP ################################################################# */
    /* Return TRUE if the swap is allowed */
    private boolean allow_SWAP(Physician phys1, Physician phys2, DayMonth day, TypeJob job1, TypeJob job2){

        //The physicians must have different
        if(phys1 == phys2) return false;
        
        //The assignments must have different
        if(job1.ID == job2.ID) return false;
        
        //Physician 1 must has permission to be assigned to job2
        if(!phys1.allowPreProc_job[day.ID][job2.ID]) return false;
        
        //Physician 2 must has permission to be assigned to job1
        if(!phys2.allowPreProc_job[day.ID][job1.ID]) return false;
        
        return true;
    }
    
    //SWAP without constraints
    private boolean moveSWAP(){
        
        Assign newBest1 = new Assign();
        Assign newBest2 = new Assign();
        int addCostBest = -1;
        boolean first = true;
                
        Assign newAssign1 = new Assign();
        Assign newAssign2 = new Assign();
                   
        int firstPhys = solution.rndSeed.nextInt(sch.noPhys)+1-maxComb;
        if(firstPhys <= 0) firstPhys = 1;
        
        for(int iPhys1=firstPhys; iPhys1<firstPhys+maxComb; iPhys1++){
            for(int iPhys2=iPhys1+1; iPhys2<firstPhys+maxComb; iPhys2++){
                Physician phys1 = sch.phys[iPhys1];
                Physician phys2 = sch.phys[iPhys2];
            
                //int iDay = solution.rndSeed.nextInt(sch.noDays)+1;
         
                for(int iDay=1; iDay<=sch.noDays; iDay++){
                    DayMonth day = sch.days[iDay];            
                    TypeJob prevJob1 = solution.assignJob[iPhys1][iDay];
                    TypeJob prevJob2 = solution.assignJob[iPhys2][iDay];
                                        
                    if(allow_SWAP(phys1,phys2,day,prevJob1,prevJob2)){
                        newAssign1.init(phys1,day,prevJob2);
                        newAssign1.addCost = solution.verifyCost(newAssign1,true);

                        newAssign2.init(phys2,day,prevJob1);
                        newAssign2.addCost = solution.verifyCost(newAssign2,true);

                        int addCost = newAssign1.addCost + newAssign2.addCost;
                        
                        //Check if the cost is accepted by criteria of the heuristic                        
                        if(addCost < 0){ 
                            if(first || addCost < addCostBest){
                                first = false;
                                newBest1.copy(newAssign1);
                                newBest2.copy(newAssign2);
                                addCostBest = addCost;
                            }
                            else if(!first && addCost == addCostBest && solution.rndSeed.nextInt(100) < 10){
                                newBest1.copy(newAssign1);
                                newBest2.copy(newAssign2);
                                addCostBest = addCost;
                            }
                        }
                    }
                }
            }
        }
        
        if(!first){
            //Update the solution with the new assignment
            solution.changeJob(newBest1);
            solution.changeJob(newBest2);
            
            //solution.initCostPhys();
            
            //Update the best solution
            solution.update_bestSolution();
            
            return true;
        }
        else return false; //solution.bestCost = -1;
    }
    
    
/*  ## 3-CHAIN ############################################################## */
    /* Return TRUE if the chain is allowed */
    private boolean allow_3CHAIN(Physician phys1, Physician phys2, Physician phys3, DayMonth day, TypeJob job1, TypeJob job2, TypeJob job3){

        //The physicians must have different
        if(phys1 == phys2 || phys1 == phys3 || phys2 == phys3) return false;
        
        //The assignments must have different
            //Physician 1 will be assigned to job3
            //Physician 2 will be assigned to job1
            //Physician 3 will be assigned to job2
        if(job1.ID == job3.ID || job2.ID == job1.ID || job3.ID == job2.ID) return false;
        
        //Physician 1 must has permission to be assigned to job3
        if(!phys1.allowPreProc_job[day.ID][job3.ID]) return false;
        
        //Physician 2 must has permission to be assigned to job1
        if(!phys2.allowPreProc_job[day.ID][job1.ID]) return false;
        
        //Physician 3 must has permission to be assigned to job2
        if(!phys3.allowPreProc_job[day.ID][job2.ID]) return false;
        
        return true;
    }
    
    /* 3 CHAIN without constraints */
    private boolean move3CHAIN(){
        
        Assign newBest1 = new Assign();
        Assign newBest2 = new Assign();
        Assign newBest3 = new Assign();
        int addCostBest = -1;
        boolean first = true;
                
        Assign newAssign1 = new Assign();
        Assign newAssign2 = new Assign();
        Assign newAssign3 = new Assign();
        
        int firstPhys = solution.rndSeed.nextInt(sch.noPhys)+1-maxComb;
        if(firstPhys <= 0) firstPhys = 1;
        
        for(int iPhys1=firstPhys; iPhys1<firstPhys+maxComb; iPhys1++){
            for(int iPhys2=iPhys1+1; iPhys2<firstPhys+maxComb; iPhys2++){
                for(int iPhys3=iPhys2+1; iPhys3<firstPhys+maxComb; iPhys3++){
                    Physician phys1 = sch.phys[iPhys1];
                    Physician phys2 = sch.phys[iPhys2];
                    Physician phys3 = sch.phys[iPhys3];

                    //int iDay = copySol.rndSeed.nextInt(sch.noDays)+1;
                    for(int iDay=1; iDay<=sch.noDays; iDay++){
                    //int iDay = solution.rndSeed.nextInt(sch.noDays)+1;
                        
                        DayMonth day = sch.days[iDay];            
                        TypeJob prevJob1 = solution.assignJob[iPhys1][iDay];
                        TypeJob prevJob2 = solution.assignJob[iPhys2][iDay];
                        TypeJob prevJob3 = solution.assignJob[iPhys3][iDay];

                        if(allow_3CHAIN(phys1,phys2,phys3,day,prevJob1,prevJob2,prevJob3)){
                            newAssign1.init(phys1,day,prevJob3);
                            newAssign1.addCost = solution.verifyCost(newAssign1,true);

                            newAssign2.init(phys2,day,prevJob1);
                            newAssign2.addCost = solution.verifyCost(newAssign2,true);

                            newAssign3.init(phys3,day,prevJob2);
                            newAssign3.addCost = solution.verifyCost(newAssign3,true);

                            int addCost = newAssign1.addCost + newAssign2.addCost + newAssign3.addCost;

                            if(addCost < 0){
                                if(first || addCost < addCostBest){
                                    first = false;
                                    newBest1.copy(newAssign1);
                                    newBest2.copy(newAssign2);
                                    newBest3.copy(newAssign3);
                                    addCostBest = addCost;
                                }
                                else if(!first && addCost == addCostBest && solution.rndSeed.nextInt(100) < 10){
                                    newBest1.copy(newAssign1);
                                    newBest2.copy(newAssign2);
                                    newBest3.copy(newAssign3);
                                    addCostBest = addCost;
                                }
                            }
                        }
                    }
                }
            }
        }
        
        if(!first){
            //Update the solution with the new assignment
            solution.changeJob(newBest1);
            solution.changeJob(newBest2);
            solution.changeJob(newBest3);
            
            //Update the best solution
            solution.update_bestSolution();
            
            return true;
        }
        else return false; //solution.bestCost = -1;
    }
 

/*  ## SHAKE ################################################################ */  
    public void shakeCHANGE(){
           
        Assign newBest = new Assign();
        Assign newAssign = new Assign();
        boolean first;
        
        for(int iPhys=1; iPhys<=sch.noPhys; iPhys++){
            
            Physician phys = sch.phys[iPhys];
            int iDay = solution.rndSeed.nextInt(sch.noDays)+1;
            
            first = true;

            DayMonth day = sch.days[iDay];            
            TypeJob prevJob = solution.assignJob[iPhys][iDay];

            for(int iJob=1; iJob<=sch.noJobs; iJob++){
                if(phys.allowPreProc_job[iDay][iJob] && prevJob.ID!=iJob){

                    TypeJob newJob = sch.jobs[iJob];                            
                    newAssign.init(phys,day,newJob);

                    if(first){
                        first = false;
                        newBest.copy(newAssign);
                    }
                    else if(solution.rndSeed.nextInt(100) < 10){
                        newBest.copy(newAssign);
                    }
                }
            }

            if(!first){
                //Update the solution with the new assignment
                solution.changeJob(newBest);

                //Update the best solution
                solution.update_bestSolution();
            }
        }
    }
    
}
