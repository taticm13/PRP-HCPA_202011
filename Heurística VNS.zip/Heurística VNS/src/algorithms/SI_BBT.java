/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package algorithms;

import schedule.Assign;
import calendar.DayMonth;
import file.WriteSolution;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import schedule.Physician;
import schedule.Schedule;
import schedule.SolutionBB;

/**
 * Order Physician and Job
 * @author Tatiana
 */
public class SI_BBT {
    
    public Schedule sch;
    public SolutionBB solution;
    
    public boolean withSort;
    public String typeSort;
    public boolean withImpPh;
    public int iExec;
    
    public SI_BBT(Schedule infoSch, int infoExec, boolean infoWithSort, boolean infowithImpPh){
        sch = infoSch;
        solution = new SolutionBB(sch);
        
        iExec = infoExec;
        withSort = infoWithSort;
        withImpPh = infowithImpPh;
        
        if(withSort) typeSort = "With Sort";
        else typeSort = "Without Sort";
        
        solution.timeInit = System.currentTimeMillis();
        
        schedulePerDay(1);
    }   
    
    
    private void schedulePerDay(int iDay){
        
        //Check if it was found a complete solution
	if(iDay > sch.noDays){
            solution.runTime = (double)(System.currentTimeMillis()-solution.timeInit)/1000;
            solution.update_bestSolution();
                
            if(solution.noSolutions > 0){
                solution.timeLimit = 0; //Ends the first fase (TB&B)
                
                //OUTPUT
                new WriteSolution(sch,solution,withSort); //Save the TB&B solution
                System.out.print(typeSort+";"+solution.bestCost+";"+solution.runTime+";");
                
                new VNS(solution,iExec,true,withSort,withImpPh);
            }
            return;
        }
        
        if(solution.timeLimit()) return;
        
        DayMonth day = sch.days[iDay];
        
        //Assignment order of the physicians (defined only in the beginning)
        int orderPhys[] = sortPhysicians(iDay);
        if(orderPhys == null) return;
        int curr_oPhys = sch.noPhys;
        int varJob_oPhys = 0;
        
        //Available jobs on the day for each physician
        ArrayList<Assign> availJobs[] = new ArrayList[sch.noPhys+1];
        for(int i=1; i<=sch.noPhys; i++) availJobs[i] = new ArrayList<>();
        
        //Current job to assign for each physician
        int indJob[] = new int[sch.noPhys+1];
        
        while(curr_oPhys > 0){
            if(solution.timeLimit()) return;
            
            //Assign jobs for each physician according to the current indJob
            boolean currFeasible = true;
            int oPhys = 0;
            
            while(oPhys < sch.noPhys && currFeasible){
                if(solution.timeLimit()) return;
            
                oPhys++;                
                int iPhys       = orderPhys[oPhys];
                Physician phys  = sch.phys[iPhys];    
                
                //Find the available assignments for each physician in the current day
                if(oPhys > varJob_oPhys){
                    availJobs[iPhys] = get_availJobs(phys,day,withSort);
                }
                
                if(availJobs[iPhys].isEmpty()){
                    currFeasible = false;
                }
                else{
                    boolean assignedPhys = false;
                    
                    //Find a feasible assign to the 'iPhys = oPhys'
                    while(!assignedPhys && indJob[iPhys] < availJobs[iPhys].size()){
                        if(solution.timeLimit()) return;                        
                        Assign assign = availJobs[iPhys].get(indJob[iPhys]);
                        
                        //Check if the assignment achieves a worst cost than the best known
                        if(solution.bestCost==-1 || solution.cost + assign.addCost < solution.bestCost){
                            if(solution.saveAssign(assign)){
                                assignedPhys = true;
                            }                            
                        }
                        if(!assignedPhys) indJob[iPhys]++;
                    }
                    currFeasible = assignedPhys;
                }
            }           
                  
            
            if(currFeasible){
                //Schedule the next day
                schedulePerDay(iDay+1);
                
                //Return of the current solution, undo the assignments
                for(int i=1; i<=sch.noPhys; i++){
                    solution.undoAssign(iDay,i);
                }                
            }
            else{//Undo the assignments of the previous physicians
                for(int k=oPhys-1; k>0; k--){
                    int j = orderPhys[k];
                    solution.undoAssign(iDay,j);
                }
                curr_oPhys = oPhys;
            }
            
            //Update the combination of assignments
            int curr_iPhys = orderPhys[curr_oPhys];
            indJob[curr_iPhys]++;
            varJob_oPhys = curr_oPhys;
            
            while(curr_oPhys > 0 && indJob[curr_iPhys] >= availJobs[curr_iPhys].size()){
                curr_oPhys--;
                curr_iPhys = orderPhys[curr_oPhys];
                indJob[curr_iPhys]++;
                varJob_oPhys = curr_oPhys;
            }

            if(curr_oPhys > 0){
                for(int j=curr_oPhys+1; j<=sch.noPhys; j++){
                    indJob[orderPhys[j]] = 0;
                }
                curr_oPhys = sch.noPhys;
            }
        }
        
    }
    
    //Sort the physician to assign on the current day
    private int[] sortPhysicians(int iDay){
        
        //First assign the fixed physicians on the day
        int order[] = new int[sch.noPhys+1];
        for(int iPhys=1; iPhys<=sch.noPhys; iPhys++){
            order[iPhys] = iPhys;
        }
        
        if(!withSort) return order;
        
        ArrayList<String> avail = new ArrayList<>();
        for(int iPhys=1; iPhys<=sch.noPhys; iPhys++){
            ArrayList<Assign> availPhys = get_availJobs(sch.phys[iPhys],sch.days[iDay],false);
            if(availPhys.isEmpty()) return null;

            int maiorDifMin = availPhys.get(0).noAvail - availPhys.get(0).difMin;
            String entry = iPhys+";"+availPhys.get(0).addCost+";"+maiorDifMin;

            avail.add(entry);
        }

        Collections.sort(avail, new Comparator<String>() {
            public int compare(String a1, String a2) {
                int cost1 = Integer.parseInt(a1.split(";")[1]);
                int cost2 = Integer.parseInt(a2.split(";")[1]);

                int availMINUSmin1 = Integer.parseInt(a1.split(";")[2]);
                int availMINUSmin2 = Integer.parseInt(a2.split(";")[2]);

                if(availMINUSmin1 > availMINUSmin2) return -1;
                else if(availMINUSmin1 == availMINUSmin2){
                    if(cost1 < cost2) return -1;
                    else if(cost1 == cost2) return 0;
                    else return 1;
                }
                else return 1;
            }
        });
        
        int noOrder = 1;
        for(String phys : avail){
            order[noOrder] = Integer.parseInt(phys.split(";")[0]);
            noOrder++;
        }
        
        return order;
    }
    
    //Search the available assignments for a physician on a day
    private ArrayList<Assign> get_availJobs(Physician phys, DayMonth day, boolean withSort){
        
        ArrayList<Assign> availAssigns = new ArrayList<>();
        
        for(int iJob=1; iJob<=sch.noJobs; iJob++){
            Assign assign = solution.assignOf_JobAllowed(day,phys,sch.jobs[iJob]);
            if(assign != null){
                availAssigns.add(assign);
                if(!withSort) return availAssigns;
            }
        }
        
        //Check if there are jobs available
        if(availAssigns.isEmpty()){
            return availAssigns;
        }
        
        //Sort the available jobs
        if(withSort) sort6(availAssigns,phys);
        
        return availAssigns;
    }
    
    
    private void sort6(ArrayList<Assign> availAssigns, Physician phys){
        Collections.sort(availAssigns, new Comparator<Assign>() {
            public int compare(Assign assign1, Assign assign2) {
                if(assign1.difMin > assign2.difMin) return -1;
                else if(assign1.difMin == assign2.difMin){
                    if(assign1.addCost < assign2.addCost) return -1;
                    else if(assign1.addCost == assign2.addCost){
                        int dif = solution.aHours_nWrkD_dayShs[phys.ID] - solution.aHours_nWrkD_nigShs[phys.ID];
                        if(dif > 0){ //DayShift greater than NighShift
                            if(assign1.job.hasNigShifts() && assign2.job.hasDayShifts()) return -1;
                            else if(assign1.job.hasNigShifts() == assign2.job.hasNigShifts()) return 0;
                            else return 1;
                        }
                        else if(dif < 0){
                            if(assign1.job.hasDayShifts() && assign2.job.hasNigShifts()) return -1;
                            else if(assign1.job.hasDayShifts() == assign2.job.hasDayShifts()) return 0;
                            else return 1;
                        }
                        else return 0;
                    }
                    else return 1;                    
                }
                else return 1;
            }
        });
    }
}
