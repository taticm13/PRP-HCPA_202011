/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package algorithms;

import calendar.DayMonth;
import calendar.Shift;
import calendar.TypeJob;
import schedule.Assign;
import schedule.Physician;
import schedule.Schedule;
import schedule.SolutionH;

/**
 *
 * @author Tatiana
 */
public class SI_FM {
    
    Schedule sch;
    SolutionH solution;
    
    public SI_FM (SolutionH infoSol){
        sch = infoSol.sch;
        solution = infoSol;
        
        while(moveCHANGE_S1(true));
        while(moveCHANGE_S5(true));
        while(moveCHANGE_S3(true));
        while(moveCHANGE_S2(true));
        while(moveCHANGE_S4(true));
        
    }
    
    /* Return a new assign with the additional cost */
    public Assign getAddCost_CHANGE(Physician phys, DayMonth day, TypeJob prevJob, TypeJob newJob){
        
        Assign newAssign = new Assign(phys,day,newJob,0);               
        int prevCost = solution.cost;
        
        //Update the solution and undo to identify the additional cost
        newAssign.addCost = solution.verifyCost(newAssign,false);
        
        //Check if the initial cost is correct
        if(prevCost != solution.cost){
            System.out.println("Day = "+day.ID);
            System.out.println("ERROR getAddCost_CHANGE[a] "+prevCost+" x "+solution.cost);
            System.exit(0);
        }
        
        return newAssign;
    }
     
    
    /*  S1. Minimum number of working hours
        CRITERIA: - Physician must has debit hours
        CHANGE:   - It will be change a day off assignment for a non-off    */
    private boolean moveCHANGE_S1(boolean updateOnlyIfBetter){
        
        Assign newBest = null;
        boolean first = true;
                
        for(int iPhys=1; iPhys<=sch.noPhys; iPhys++){
            Physician phys = sch.phys[iPhys];
            
            if(solution.aHours_total[iPhys] < phys.workload){
                for(int iDay=1; iDay<=sch.noDays; iDay++){
                    DayMonth day = sch.days[iDay];            
                    TypeJob prevJob = solution.assignJob[iPhys][iDay];

                    if(prevJob.isOFF()){
                        for(int iJob=1; iJob<=sch.noJobs; iJob++){
                            if(phys.allowPreProc_job[iDay][iJob] && prevJob.ID!=iJob){

                                TypeJob newJob = sch.jobs[iJob];                            
                                Assign newAssign = getAddCost_CHANGE(phys,day,prevJob,newJob);

                                //Check if the cost is accepted by criteria of the heuristic                        
                                if(newAssign.addCost < 0){ 
                                    if(first || newAssign.addCost < newBest.addCost){
                                        first = false;
                                        newBest = newAssign;
                                    }
                                    else if(!first && newAssign.addCost == newBest.addCost && solution.rndSeed.nextInt(100) < 10){
                                        newBest = newAssign;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        
        if(newBest!=null && (!updateOnlyIfBetter || newBest.addCost < 0)){
            //Update the solution with the new assignment
            solution.changeJob(newBest);
            
            //Update the best solution
            solution.update_bestSolution();
            
            return true;
        }
        
        return false;
    }
    
    /*  S2. Maximum number of working hours
        CRITERIA: - Physician must has extra hours
        CHANGE:   - It will be change non-off assignment for a day off    */
    private boolean moveCHANGE_S2(boolean updateOnlyIfBetter){
        
        Assign newBest = null;
        boolean first = true;
                
        for(int iPhys=1; iPhys<=sch.noPhys; iPhys++){
            Physician phys = sch.phys[iPhys];
            
            if(solution.aHours_total[iPhys] > phys.workload){
                for(int iDay=1; iDay<=sch.noDays; iDay++){
                    DayMonth day = sch.days[iDay];            
                    TypeJob prevJob = solution.assignJob[iPhys][iDay];

                    if(!prevJob.isOFF()){
                        int iJob = sch.jobID[Shift.OFF.index][0];
                        if(phys.allowPreProc_job[iDay][iJob] && prevJob.ID!=iJob){

                            TypeJob newJob = sch.jobs[iJob];                            
                            Assign newAssign = getAddCost_CHANGE(phys,day,prevJob,newJob);

                            //Check if the cost is accepted by criteria of the heuristic                        
                            if(newAssign.addCost < 0){ 
                                if(first || newAssign.addCost < newBest.addCost){
                                    first = false;
                                    newBest = newAssign;
                                }
                                else if(!first && newAssign.addCost == newBest.addCost && solution.rndSeed.nextInt(100) < 10){
                                    newBest = newAssign;
                                }
                            }
                        }
                    }
                }
            }
        }
        
        if(newBest!=null && (!updateOnlyIfBetter || newBest.addCost < 0)){
            //Update the solution with the new assignment
            solution.changeJob(newBest);
            
            //Update the best solution
            solution.update_bestSolution();
            
            return true;
        }
        
        return false;
    }
    
    /*  S3. Minimum number of working hours on non-working days
        CRITERIA: - Physician must has number of hours on non-working days below the ideal
        CHANGE:   - It will be change a day off assignment on non-working day for a non-off    */
    private boolean moveCHANGE_S3(boolean updateOnlyIfBetter){
        
        Assign newBest = null;
        boolean first = true;
                
        for(int iPhys=1; iPhys<=sch.noPhys; iPhys++){
            Physician phys = sch.phys[iPhys];
            
            if(solution.aHours_nWrkD_allSh[iPhys] < phys.idealHours_nWrkD){
                for(int iDay=1; iDay<=sch.noDays; iDay++){
                    DayMonth day = sch.days[iDay];            
                    TypeJob prevJob = solution.assignJob[iPhys][iDay];

                    if(!day.isWorkDay && prevJob.isOFF()){
                        for(int iJob=1; iJob<=sch.noJobs; iJob++){
                            if(phys.allowPreProc_job[iDay][iJob] && prevJob.ID!=iJob){
                                TypeJob newJob = sch.jobs[iJob];                            
                                Assign newAssign = getAddCost_CHANGE(phys,day,prevJob,newJob);
                                
                                //Check if the cost is accepted by criteria of the heuristic                        
                                if(newAssign.addCost < 0){ 
                                    if(first || newAssign.addCost < newBest.addCost){
                                        first = false;
                                        newBest = newAssign;
                                    }
                                    else if(!first && newAssign.addCost == newBest.addCost && solution.rndSeed.nextInt(100) < 10){
                                        newBest = newAssign;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        
        if(newBest!=null && (!updateOnlyIfBetter || newBest.addCost < 0)){
            //Update the solution with the new assignment
            solution.changeJob(newBest);
            
            //Update the best solution
            solution.update_bestSolution();
            
            return true;
        }
        
        return false;
    }
    
    /*  S4. Maximum number of working hours on non-working days
        CRITERIA: - Physician must has number of hours on non-working days above the ideal
        CHANGE:   - It will be change a day off assignment on non-working day for a non-off    */
    private boolean moveCHANGE_S4(boolean updateOnlyIfBetter){
        
        Assign newBest = null;
        boolean first = true;
                
        for(int iPhys=1; iPhys<=sch.noPhys; iPhys++){
            Physician phys = sch.phys[iPhys];
            
            if(solution.aHours_nWrkD_allSh[iPhys] > phys.idealHours_nWrkD){
                for(int iDay=1; iDay<=sch.noDays; iDay++){
                    DayMonth day = sch.days[iDay];            
                    TypeJob prevJob = solution.assignJob[iPhys][iDay];

                    if(!day.isWorkDay && !prevJob.isOFF()){
                        int iJob = sch.jobID[Shift.OFF.index][0];
                        if(phys.allowPreProc_job[iDay][iJob] && prevJob.ID!=iJob){

                            TypeJob newJob = sch.jobs[iJob];                            
                            Assign newAssign = getAddCost_CHANGE(phys,day,prevJob,newJob);

                            //Check if the cost is accepted by criteria of the heuristic                        
                            if(newAssign.addCost < 0){ 
                                if(first || newAssign.addCost < newBest.addCost){
                                    first = false;
                                    newBest = newAssign;
                                }
                                else if(!first && newAssign.addCost == newBest.addCost && solution.rndSeed.nextInt(100) < 10){
                                    newBest = newAssign;
                                }
                            }
                        }
                    }
                }
            }
        }
        
        if(newBest!=null && (!updateOnlyIfBetter || newBest.addCost < 0)){
            //Update the solution with the new assignment
            solution.changeJob(newBest);
            
            //Update the best solution
            solution.update_bestSolution();
            
            return true;
        }
        
        return false;
    }
    
    /*  S5. Balance of hours on non-working days */
    private boolean moveCHANGE_S5(boolean updateOnlyIfBetter){
        
        Assign newBest = null;
        boolean first = true;
                
        for(int iPhys=1; iPhys<=sch.noPhys; iPhys++){
            Physician phys = sch.phys[iPhys];
            
            //Number of hours in day shifts is greater than night shifts
            if(solution.aHours_nWrkD_dayShs[iPhys] > solution.aHours_nWrkD_nigShs[iPhys]){
                for(int iDay=1; iDay<=sch.noDays; iDay++){
                    DayMonth day = sch.days[iDay];            
                    TypeJob prevJob = solution.assignJob[iPhys][iDay];

                    if(!day.isWorkDay && (prevJob.isOFF() || prevJob.hasDayShifts())){
                        for(int iJob=1; iJob<=sch.noJobs; iJob++){
                            TypeJob newJob = sch.jobs[iJob];
                            if(newJob.isOFF() || newJob.hasNigShifts()){                            
                                if(phys.allowPreProc_job[iDay][iJob] && prevJob.ID!=iJob){
                                    Assign newAssign = getAddCost_CHANGE(phys,day,prevJob,newJob);

                                    //Check if the cost is accepted by criteria of the heuristic                        
                                    if(!updateOnlyIfBetter || newAssign.addCost < 0){ 
                                        if(first || newAssign.addCost < newBest.addCost){
                                            first = false;
                                            newBest = newAssign;
                                        }
                                        else if(!first && newAssign.addCost == newBest.addCost && solution.rndSeed.nextInt(100) < 10){
                                            newBest = newAssign;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            //Number of hours in night shifts is greater than day shifts
            else{
                for(int iDay=1; iDay<=sch.noDays; iDay++){
                    DayMonth day = sch.days[iDay];            
                    TypeJob prevJob = solution.assignJob[iPhys][iDay];

                    if(!day.isWorkDay && (prevJob.isOFF() || prevJob.hasNigShifts())){
                        for(int iJob=1; iJob<=sch.noJobs; iJob++){
                            TypeJob newJob = sch.jobs[iJob];
                            if(newJob.isOFF() || newJob.hasDayShifts()){                            
                                if(phys.allowPreProc_job[iDay][iJob] && prevJob.ID!=iJob){
                                    Assign newAssign = getAddCost_CHANGE(phys,day,prevJob,newJob);

                                    //Check if the cost is accepted by criteria of the heuristic                        
                                    if(!updateOnlyIfBetter || newAssign.addCost < 0){ 
                                        if(first || newAssign.addCost < newBest.addCost){
                                            first = false;
                                            newBest = newAssign;
                                        }
                                        else if(!first && newAssign.addCost == newBest.addCost && solution.rndSeed.nextInt(100) < 10){
                                            newBest = newAssign;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        
        if(newBest!=null && (!updateOnlyIfBetter || newBest.addCost < 0)){
            //Update the solution with the new assignment
            solution.changeJob(newBest);
            
            //Update the best solution
            solution.update_bestSolution();
            
            return true;
        }
        
        return false;
    }
    
}
