/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package schedule;

import calendar.DayMonth;
import calendar.TypeJob;
import calendar.WeekDay;
import java.util.Random;

/**
 *
 * @author Tatiana
 */
public class SolutionH {
    
    public Schedule sch;
    public Random rndSeed;
    public double timeInit;
    public double runTime;
    public double timeLimit;
    public int noIter;
    public int noIter_nImpr;
    public int maxIter_nImpr;
    
    //###################################### INFORMATION ABOUT THE BEST SOLUTION
    public int bestCost;                //                                  Cost of the best solution
    public int bestCostImprov;
    public double runtimeImprov;
    public int best_costSC[];           //[per Constraint]                  Total cost of each soft constraint
    public TypeJob[][] best_assignJob;  //[per Physician, per Day]          Job assigned for each day
    
    //################################### INFORMATION ABOUT THE CURRENT SOLUTION
    public int cost;                    //Cost of the CURRENT solution
    public int aHours_total[];          //[per Physician]                   Number of hours assigned in the CURRENT solution
    public int aHours_nWrkD_allSh[];    //[per Physician]                   Number of hours assigned on not working days in the CURRENT solution
    public int aHours_nWrkD_dayShs[];   //[per Physician]                   Number of hours assigned in day shifts of not working days in the CURRENT solution
    public int aHours_nWrkD_nigShs[];   //[per Physician]                   Number of hours assigned in night shifts of not working days in the CURRENT solution
    public int aHours_perLoc[][];       //[per Physician, per Location]     Number of hours assigned in each location in the CURRENT solution
    public int noAssigns_perWKND[][];   //[per Physician, per Week]         Number of assignments in each weekend in the CURRENT solution
    public int noAssigned_WKND[];       //[per Physician]                   Number of weekends assigned in the CURRENT solution
    public int consecNight[][];         //[per Physician, per Day]          Number of consecutive night shifts in the CURRENT solution
    public TypeJob[][] assignJob;       //[per Physician, per Day]          Job assigned for each day in the CURRENT solution
    public int noAssign[][];            //[per Day, per Job]                Number of physicians assigned to the DSL in the CURRENT solution
    
    //####################################### INFORMATION ABOUT SOFT CONSTRAINTS
    public int noSoftC;    
    public int weightSC[];              //[per Constraint]                  Weight of each soft constraint
    public int costSC[];                //[per Constraint]                  Total cost of each soft constraint
    
    //Increasing cost per physician
    public int costS1[];                //[per Physician]                   Minimum number of working hours
    public int costS2[];                //[per Physician]                   Maximum number of working hours
    public int costS3[];                //[per Physician]                   Minimum number of working hours on non-working days
    public int costS4[];                //[per Physician]                   Maximum number of working hours on non-working days
    public int costS5[];                //[per Physician]                   Balance of hours on non-working days
    public int costS6[][];              //[per Physician, per Week]         Incomplete weekend
    public int costS7[];                //[per Physician]                   Maximum number of weekends assigned
    public int costS8[][];              //[per Physician, per Day]          Maximum number of consecutive night shifts
    public int costS9[][];              //[per Physician, per Day]          Location non-preferential
    public int costS10[][];             //[per Physician, per Day]          Day/Shift non-preferential
    
    //####################################### INFORMATION ABOUT HARD CONSTRAINTS    
    //Increasing hard constraint
    int noHardC;
    public int weightHC = 10000;
    public int costHARD;
    public int costH1[][];              //[per Day, per Job]
    public int costH2[][];              //[per Day, per Job]
    public int costH8[][];              //[per Physician, per Day]
    
    public SolutionH(Schedule infoSch, SolutionBB initialSol){
        sch = infoSch;
        rndSeed = new Random();
        maxIter_nImpr = sch.noPhys * 10;
        
        if(sch.noPhys >= 250)       timeLimit = 5*60;
        else if(sch.noPhys >= 100)  timeLimit = 3*60;
        else                        timeLimit = 1*60;
        
        //BEST solution
        bestCost            = initialSol.cost;
        best_assignJob      = new TypeJob[sch.noPhys+1][sch.noDays+1];
        
        //CURRENT solution
        cost                = initialSol.cost;
        aHours_total        = new int[sch.noPhys+1];
        aHours_nWrkD_allSh  = new int[sch.noPhys+1];
        aHours_nWrkD_dayShs = new int[sch.noPhys+1];
        aHours_nWrkD_nigShs = new int[sch.noPhys+1];
        aHours_perLoc       = new int[sch.noPhys+1][sch.noLocs+1];
        noAssigns_perWKND   = new int[sch.noPhys+1][sch.noWeeks+1];
        noAssigned_WKND     = new int[sch.noPhys+1];
        consecNight         = new int[sch.noPhys+1][sch.noDays+1];
        assignJob           = new TypeJob[sch.noPhys+1][sch.noDays+1];
        noAssign            = new int[sch.noDays+1][sch.noJobs+1];
        
        //SOFT contraints
        noSoftC     = initialSol.noSoftC;        
        weightSC    = new int[noSoftC+1];
        costSC      = new int[noSoftC+1];
        best_costSC = new int[noSoftC+1];
        
        costS1  = new int[sch.noPhys+1];
        costS2  = new int[sch.noPhys+1];
        costS3  = new int[sch.noPhys+1];
        costS4  = new int[sch.noPhys+1];
        costS5  = new int[sch.noPhys+1];
        costS6  = new int[sch.noPhys+1][sch.noWeeks+1];
        costS7  = new int[sch.noPhys+1];
        costS8  = new int[sch.noPhys+1][sch.noDays+1];
        costS9  = new int[sch.noPhys+1][sch.noDays+1];
        costS10 = new int[sch.noPhys+1][sch.noDays+1];
        
        //Copy of information
        for(int iPhys=1; iPhys<=sch.noPhys; iPhys++){
            
            aHours_total[iPhys]         = initialSol.aHours_total[iPhys];
            aHours_nWrkD_allSh[iPhys]   = initialSol.aHours_nWrkD_allSh[iPhys];
            aHours_nWrkD_dayShs[iPhys]  = initialSol.aHours_nWrkD_dayShs[iPhys];
            aHours_nWrkD_nigShs[iPhys]  = initialSol.aHours_nWrkD_nigShs[iPhys];
            noAssigned_WKND[iPhys]      = initialSol.noAssigned_WKND[iPhys];
            
            costS1[iPhys] = initialSol.costS1[iPhys];
            costS3[iPhys] = initialSol.costS3[iPhys];
            costS5[iPhys] = initialSol.costS5[iPhys];
            
            for(int iLoc=1; iLoc<=sch.noLocs; iLoc++){
                aHours_perLoc[iPhys][iLoc] = initialSol.aHours_perLoc[iPhys][iLoc];
            }
            
            for(int iWeek=1; iWeek<=sch.noWeeks; iWeek++){
                noAssigns_perWKND[iPhys][iWeek] = initialSol.noAssigns_perWKND[iPhys][iWeek];
                costS6[iPhys][iWeek] = initialSol.costS6[iPhys][iWeek];
            }
            
            for(int iDay=1; iDay<=sch.noDays; iDay++){
                best_assignJob[iPhys][iDay] = initialSol.assignJob[iPhys][iDay].copy();
                consecNight[iPhys][iDay]    = initialSol.consecNight[iPhys][iDay];
                assignJob[iPhys][iDay]      = initialSol.assignJob[iPhys][iDay].copy();
                
                costS8[iPhys][iDay]     = initialSol.costS8[iPhys][iDay];
                costS9[iPhys][iDay]     = initialSol.costS9[iPhys][iDay];
                costS10[iPhys][iDay]    = initialSol.costS10[iPhys][iDay];
                
                if(iPhys==1){
                    for(int iJob=1; iJob<=sch.noJobs; iJob++){
                        noAssign[iDay][iJob] = initialSol.noAssign[iDay][iJob];
                    }
                }
                
                costS2[iPhys] += initialSol.costS2[iPhys][iDay];
                costS4[iPhys] += initialSol.costS4[iPhys][iDay];
                costS7[iPhys] += initialSol.costS7[iPhys][iDay];
            }
        }
        
        for(int iS=1; iS<=noSoftC; iS++){
            weightSC[iS]    = initialSol.weightSC[iS];
            costSC[iS]      = initialSol.costSC[iS];
            best_costSC[iS] = initialSol.costSC[iS];            
        }
        
        //HARD contraints
        noHardC = 8;
        weightHC = 100000;
        costH1 = new int[sch.noDays+1][sch.noJobs+1];
        costH2 = new int[sch.noDays+1][sch.noJobs+1];
        costH8 = new int[sch.noPhys+1][sch.noDays+1];
    }
    
/*  ## AUXILIAR FUNCTIONS ################################################### */
    /* Return TRUE if it was achieved the time limit, stopping the algorithm */
    public boolean timeLimit(){
        runTime = (double)(System.currentTimeMillis()-timeInit)/1000;
        if(runTime > timeLimit){
            return true;
        }
        else return false;
    }
    
    /* Update the best solution when achieves a complete solution with better cost */
    public void update_bestSolution(){
        if(bestCost == -1 || cost < bestCost){
            //System.out.println("Atualizou best");
            bestCost = cost;            
            for(int i=1; i<=noSoftC; i++){
                best_costSC[i] = costSC[i];
            }
            
            for(int iPhys=1; iPhys<=sch.noPhys; iPhys++){
                for(int iDay=1; iDay<=sch.noDays; iDay++){
                    best_assignJob[iPhys][iDay] = sch.jobs[assignJob[iPhys][iDay].ID];
                }
            }
        }
    }
    
    
/*  ## ASSIGN PHYSICIAN ##################################################### */
    public int verifyCost(Assign newAssign, boolean swap){
        int iPhys = newAssign.phys.ID;
        int iDay = newAssign.day.ID;
        
        Physician phys = sch.phys[iPhys];
        DayMonth day = sch.days[iDay];
        
        TypeJob prevJob = assignJob[iPhys][iDay];
        TypeJob newJob = newAssign.job;
        
        int extraCost = 0;
        
        /* HARD CONSTRAINTS */
        if(!swap){
            //H1 - Minimum number of physicians assigned to each day/shift/location
            extraCost += -1 * costH1[iDay][prevJob.ID];
            if(noAssign[iDay][prevJob.ID] - 1 < sch.minAssign[iDay][prevJob.ID]){
                extraCost += weightHC * (sch.minAssign[iDay][prevJob.ID] - (noAssign[iDay][prevJob.ID] - 1));
            }

            extraCost += -1 * costH1[iDay][newJob.ID];
            if(noAssign[iDay][newJob.ID] + 1 < sch.minAssign[iDay][newJob.ID]){
                extraCost += weightHC * (sch.minAssign[iDay][newJob.ID] - (noAssign[iDay][newJob.ID] + 1));
            }

            //H2 - Maximum number of physicians assigned to each day/shift/location
            extraCost += -1 * costH2[iDay][prevJob.ID];
            if(noAssign[iDay][prevJob.ID] - 1 > sch.maxAssign[iDay][prevJob.ID]){
                extraCost += weightHC * ((noAssign[iDay][prevJob.ID] - 1) - sch.maxAssign[iDay][prevJob.ID]);
            }

            extraCost += -1 * costH2[iDay][newJob.ID];
            if(noAssign[iDay][newJob.ID] + 1 > sch.maxAssign[iDay][newJob.ID]){
                extraCost += weightHC * ((noAssign[iDay][newJob.ID] + 1) - sch.maxAssign[iDay][newJob.ID]);
            }
        }
        
        //H8 - CURRENT DAY
        if(iDay > 1){
            extraCost += -1 * costH8[iPhys][iDay];

            //If day before was assigned with NIG and the current day was assigned with DAY, MOR or AFT
            if(assignJob[iPhys][iDay-1].hasNigShifts() && newJob.hasDayShifts()){
                extraCost += weightHC;
            }
        }
        
        //H8 - NEXT DAY
        if(iDay < sch.noDays){
            extraCost += -1 * costH8[iPhys][iDay+1];

            //If the current day was assigned with NIG and the next day was assigned with DAY, MOR or AFT
            if(newJob.hasNigShifts() && assignJob[iPhys][iDay+1].hasDayShifts()){
                extraCost += weightHC;
            }
        }
        
        //######################################################################
        //S1 - Minimum number of working hours
        int aHours = aHours_total[iPhys] - prevJob.noHours() + newJob.noHours();
        
        extraCost += -1 * costS1[iPhys];        
        if(aHours < phys.workload){
            extraCost += weightSC[1] * (phys.workload - aHours);
        }        
        
        //######################################################################
        //S2 - Maximum number of working hours
        extraCost += -1 * costS2[iPhys];        
        if(aHours > phys.workload){
            extraCost += weightSC[2] * (aHours - phys.workload);
        }
        
        //######################################################################
        //S3 - Minimum number of working hours on non-working days
        if(!day.isWorkDay){
            int aHoursSh = aHours_nWrkD_allSh[iPhys] - prevJob.noHours() + newJob.noHours();
        
            extraCost += -1 * costS3[iPhys];        
            if(aHoursSh < phys.idealHours_nWrkD){
                extraCost += weightSC[3]* (phys.idealHours_nWrkD - aHoursSh);
            }
        
            //######################################################################
            //S4 - Maximum number of working hours on non-working days
            extraCost += -1 * costS4[iPhys];        
            if(aHoursSh > phys.idealHours_nWrkD){
                extraCost += weightSC[4]* (aHoursSh - phys.idealHours_nWrkD);
            }
            
            //######################################################################
            //S5 - Balance of hours on non-working days
            int daySh = aHours_nWrkD_dayShs[iPhys];
            int nigSh = aHours_nWrkD_nigShs[iPhys];
            
            if(prevJob.hasDayShifts())  daySh -= prevJob.noHours();
            else nigSh -= prevJob.noHours();
            if(newJob.hasDayShifts()) daySh += newJob.noHours();
            else nigSh += newJob.noHours();
            
            
            extraCost += -1 * costS5[iPhys];
            extraCost += weightSC[5]* Math.abs(daySh - nigSh);
        }
        
        //######################################################################
        //S6 - Incomplete weekend
        if(day.isWKND && (prevJob.isOFF() != newJob.isOFF())){
            int iWeek = newAssign.day.week;
            
            int noAssign_perWKND = noAssigns_perWKND[iPhys][iWeek];
            int noAssignWKND = noAssigned_WKND[iPhys];
            
            if(prevJob.isOFF()){
                noAssign_perWKND++;

                //Number of assigned weekends
                if(noAssign_perWKND == 1){
                    noAssignWKND++;
                }
            }
            else{
                noAssign_perWKND--;

                //Number of assigned weekends
                if(noAssign_perWKND == 0){
                    noAssignWKND--;
                }
            }
            
            extraCost += -1 * costS6[iPhys][iWeek];
            
            if(noAssign_perWKND == 1 && (iWeek < sch.noWeeks || day.dayWeek != WeekDay.SATURDAY)){
                extraCost += weightSC[6];
            }
        
            //######################################################################
            //S7 - Maximum number of weekends assigned
            extraCost += -1 * costS7[iPhys];
            
            if(noAssignWKND > 2){
                extraCost += weightSC[7] * (noAssignWKND - 2);
            }        
        }
        
        //######################################################################
        //S8 - Maximum number of consecutive night shifts
        if(newJob.shift != prevJob.shift && (prevJob.hasNigShifts() || newJob.hasNigShifts())){
            
            
                //Update the current day
                if(newJob.hasNigShifts()){
                    if(day.ID > 1){
                        consecNight[iPhys][day.ID] = consecNight[iPhys][day.ID-1] + 1;
                    }
                    else consecNight[iPhys][day.ID] = 1;
                }
                else consecNight[iPhys][day.ID] = 0;

                //Update the next days
                for(int jDay=iDay+1; jDay<=sch.noDays; jDay++){
                    if(assignJob[iPhys][jDay].hasNigShifts()){
                        consecNight[iPhys][jDay] = consecNight[iPhys][jDay-1] + 1;
                    }
                    else{
                        consecNight[iPhys][jDay] = 0;
                        jDay = sch.noDays+1;
                    }
                }
            
            
            //Update the current day
            extraCost += -1 * costS8[iPhys][iDay];
            
            if(newJob.hasNigShifts() && consecNight[iPhys][iDay] > 3){
                extraCost += weightSC[8];
            }
            
            //Update the next days
            for(int jDay=iDay+1; jDay<=sch.noDays; jDay++){
                extraCost += -1 * costS8[iPhys][jDay];
                
                if(assignJob[iPhys][jDay].hasNigShifts()){
                    if(consecNight[iPhys][jDay] > 3) extraCost += weightSC[8];
                }
                else jDay = sch.noDays+1;
            }
            
                //Update the current day
                if(prevJob.hasNigShifts()){
                    if(day.ID > 1){
                        consecNight[iPhys][day.ID] = consecNight[iPhys][day.ID-1] + 1;
                    }
                    else consecNight[iPhys][day.ID] = 1;
                }
                else consecNight[iPhys][day.ID] = 0;

                //Update the next days
                for(int jDay=iDay+1; jDay<=sch.noDays; jDay++){
                    if(assignJob[iPhys][jDay].hasNigShifts()){
                        consecNight[iPhys][jDay] = consecNight[iPhys][jDay-1] + 1;
                    }
                    else{
                        consecNight[iPhys][jDay] = 0;
                        jDay = sch.noDays+1;
                    }
                }
        }
        
        //######################################################################
        //S9 - Location non-preferential
        if(newJob.loc != prevJob.loc || newJob.noShifts() != prevJob.noShifts()){
            extraCost += -1 * costS9[iPhys][iDay];
            
            if(phys.locNonPref[newJob.loc]){
                extraCost += weightSC[9] * newJob.noShifts();
            }
        }
        
        //######################################################################
        //S10 - Day/Shift non-preferential
        if(newJob.shift != prevJob.shift){
            extraCost += -1 * costS10[iPhys][iDay];
            
            if(phys.penaltyAssign[iDay][newJob.shift.index] > 0){
                extraCost += weightSC[10] * phys.penaltyAssign[iDay][newJob.shift.index];
            }
        }
        
        return extraCost;
    }
    
    /* Return the ADDITIONAL COST with the change */
    public int changeJob(Assign newAssign){
        return changeJob(newAssign,false);
    }
    public int changeJob(Assign newAssign, boolean swap){
        int iPhys = newAssign.phys.ID;
        int iDay = newAssign.day.ID;
        
        Physician phys = sch.phys[iPhys];
        DayMonth day = sch.days[iDay];
        
        TypeJob prevJob = assignJob[iPhys][iDay];
        TypeJob newJob = newAssign.job;
        
        
        //########################################## UPDATE THE CURRENT SOLUTION
        //Assignment of the day
        assignJob[iPhys][iDay] = newJob;
        
        //Number of assignments
        if(!prevJob.isOFF()) noAssign[iDay][prevJob.ID]--;
        if(!newJob.isOFF()) {
            noAssign[iDay][newJob.ID]++;
        }
        
        //####################################### UPDATE THE AUXILIAR STRUCTURES
        //Total number of hours
        aHours_total[iPhys] -= prevJob.noHours();
        aHours_total[iPhys] += newJob.noHours();
        
        //Number of hours on not working hours
        if(!day.isWorkDay){
            aHours_nWrkD_allSh[iPhys] -= prevJob.noHours();
            aHours_nWrkD_allSh[iPhys] += newJob.noHours();
            
            if(prevJob.hasDayShifts()) aHours_nWrkD_dayShs[iPhys] -= prevJob.noHours();
            else aHours_nWrkD_nigShs[iPhys] -= prevJob.noHours();
            if(newJob.hasDayShifts()) aHours_nWrkD_dayShs[iPhys] += newJob.noHours();
            else aHours_nWrkD_nigShs[iPhys] += newJob.noHours();
        }
        
        //Number of hours in the location
        aHours_perLoc[iPhys][prevJob.loc] -= prevJob.noHours();
        aHours_perLoc[iPhys][newJob.loc] += newJob.noHours();
        
        //Number of assignments in each weekend
        if(day.isWKND && (prevJob.isOFF() != newJob.isOFF())){
            if(prevJob.isOFF()){
                noAssigns_perWKND[iPhys][day.week]++;
            
                //Number of assigned weekends
                if(noAssigns_perWKND[iPhys][day.week] == 1){
                    noAssigned_WKND[iPhys]++;
                }
            }
            else{
                noAssigns_perWKND[iPhys][day.week]--;
            
                //Number of assigned weekends
                if(noAssigns_perWKND[iPhys][day.week] == 0){
                    noAssigned_WKND[iPhys]--;
                }
            }
        }
        
        //Consecutive nights assigned
        if(newJob.shift != prevJob.shift && (newJob.hasNigShifts() || prevJob.hasNigShifts())){
            //Update the current day
            if(newJob.hasNigShifts()){
                if(day.ID > 1){
                    consecNight[iPhys][day.ID] = consecNight[iPhys][day.ID-1] + 1;
                }
                else consecNight[iPhys][day.ID] = 1;
            }
            else consecNight[iPhys][day.ID] = 0;
            
            //Update the next days
            for(int jDay=iDay+1; jDay<=sch.noDays; jDay++){
                if(assignJob[iPhys][jDay].hasNigShifts()){
                    consecNight[iPhys][jDay] = consecNight[iPhys][jDay-1] + 1;
                }
                else{
                    consecNight[iPhys][jDay] = 0;
                    jDay = sch.noDays+1;
                }
            }
        }
        
        int prevCost = cost;
        
        //################################################# UPDATE THE HARD COST
        //H1 - Minimum number of physicians assigned to each day/shift/location
        //H2 - Maximum number of physicians assigned to each day/shift/location
        if(!swap){
            validateH1andH2(day.ID,prevJob);
            validateH1andH2(day.ID,newJob);
        }
        
        //H3 - Physician without permission in the location
        //The heuristic will never assign a physician to a location without permission
        
        //H4 - Physician locked on day/shift
        //The heuristic will never assign a physician to a lock day/shift
        
        //H5 - Physician with fixed assignment
        //The heuristic will never unassign a physician of a fixed assignment
        
        //H6 - Valid shifts according the type of the day
        //The heuristic will never assign invalid shifts on the day
        
        //H7 - Number of locations per day
        //The heuristic will never assign more than 1 location per day
        
        //H8 - Invalid assignments on consecutive days
        validateH8(phys,day,newJob);
        
        
        //################################################# UPDATE THE SOFT COST
        validateSOFT(phys,day,prevJob);
        
        return cost - prevCost;
    }
    
    private void validateSOFT(Physician phys, DayMonth day, TypeJob prevJob){
        
        int iDay = day.ID;
        int iPhys = phys.ID;
        int iWeek = day.week;
        TypeJob job = assignJob[iPhys][iDay];
        
        int extraC [] = new int[noSoftC+1];
        
        //######################################################################
        //S1 - Minimum number of working hours
        extraC[1] = -1 * costS1[iPhys];        
        if(aHours_total[iPhys] < phys.workload){
            costS1[iPhys] = weightSC[1]* (phys.workload - aHours_total[iPhys]);
            extraC[1] += costS1[iPhys];
        }
        else costS1[iPhys] = 0;
        
        //######################################################################
        //S2 - Maximum number of working hours
        extraC[2] = -1 * costS2[iPhys];        
        if(aHours_total[iPhys] > phys.workload){
            costS2[iPhys] = weightSC[2]* (aHours_total[iPhys] - phys.workload);
            extraC[2] += costS2[iPhys];
        }
        else costS2[iPhys] = 0;
        
        //######################################################################
        //S3 - Minimum number of working hours on non-working days
        if(!day.isWorkDay){
            extraC[3] = -1 * costS3[iPhys];        
            if(aHours_nWrkD_allSh[iPhys] < phys.idealHours_nWrkD){
                costS3[iPhys] = weightSC[3]* (phys.idealHours_nWrkD - aHours_nWrkD_allSh[iPhys]);
                extraC[3] += costS3[iPhys];
            }
            else costS3[iPhys] = 0;
        
        //######################################################################
        //S4 - Maximum number of working hours on non-working days
            extraC[4] = -1 * costS4[iPhys];        
            if(aHours_nWrkD_allSh[iPhys] > phys.idealHours_nWrkD){
                costS4[iPhys] = weightSC[4]* (aHours_nWrkD_allSh[iPhys] - phys.idealHours_nWrkD);
                extraC[4] += costS4[iPhys];
            }
            else costS4[iPhys] = 0;
            
        //######################################################################
        //S5 - Balance of hours on non-working days
            extraC[5] = -1 * costS5[iPhys];
            costS5[iPhys] = weightSC[5]* Math.abs(aHours_nWrkD_dayShs[iPhys] - aHours_nWrkD_nigShs[iPhys]);
            extraC[5] += costS5[iPhys];
        
        }
        
        //######################################################################
        //S6 - Incomplete weekend
        if(day.isWKND){
            extraC[6] = -1 * costS6[iPhys][iWeek];
            
            if(noAssigns_perWKND[iPhys][iWeek] == 1 && (iWeek < sch.noWeeks || day.dayWeek != WeekDay.SATURDAY)){
                costS6[iPhys][iWeek] = weightSC[6];
                extraC[6] += costS6[iPhys][iWeek];
            }
            else costS6[iPhys][iWeek] = 0;
        
        
        //######################################################################
        //S7 - Maximum number of weekends assigned
            extraC[7] = -1 * costS7[iPhys];
            
            if(noAssigned_WKND[iPhys] > 2){
                costS7[iPhys] = weightSC[7] * (noAssigned_WKND[iPhys] - 2);
                extraC[7] += costS7[iPhys];
            }
            else costS7[iPhys] = 0;
        
        }
        
        //######################################################################
        //S8 - Maximum number of consecutive night shifts
        if(job.shift != prevJob.shift && (prevJob.hasNigShifts() || job.hasNigShifts())){
            //Update the current day
            extraC[8] += -1 * costS8[iPhys][iDay];
            
            if(job.hasNigShifts() && consecNight[iPhys][iDay] > 3){
                costS8[iPhys][iDay] = weightSC[8];
                extraC[8] += costS8[iPhys][iDay];
            }
            else costS8[iPhys][iDay] = 0;
        
            //Update the next days
            for(int jDay=iDay+1; jDay<=sch.noDays; jDay++){
                extraC[8] += -1 * costS8[iPhys][jDay];
                
                if(assignJob[iPhys][jDay].hasNigShifts()){
                    if(consecNight[iPhys][jDay] > 3){
                        costS8[iPhys][jDay] = weightSC[8];
                        extraC[8] += costS8[iPhys][jDay];
                    }
                    else costS8[iPhys][jDay] = 0;
                }
                else{
                    costS8[iPhys][jDay] = 0;
                    jDay = sch.noDays+1;
                }
            }
        }        
        
        //######################################################################
        //S9 - Location non-preferential
        if(job.loc != prevJob.loc || job.noShifts() != prevJob.noShifts()){
            extraC[9] = -1 * costS9[iPhys][iDay];
            
            if(phys.locNonPref[job.loc]){
                costS9[iPhys][iDay] = weightSC[9] * job.noShifts();
                extraC[9] += costS9[iPhys][iDay];
            }
            else costS9[iPhys][iDay] = 0;
        }
        
        //######################################################################
        //S10 - Day/Shift non-preferential
        if(job.shift != prevJob.shift){
            extraC[10] = -1 * costS10[iPhys][iDay];
            
            if(phys.penaltyAssign[iDay][job.shift.index] > 0){
                costS10[iPhys][iDay] = weightSC[10] * phys.penaltyAssign[iDay][job.shift.index];
                extraC[10] += costS10[iPhys][iDay];
            }
            else costS10[iPhys][iDay] = 0;
        }
        
        //Update the combined costs
        for(int i=1; i<=noSoftC; i++){
            costSC[i]   += extraC[i];
            cost        += extraC[i];
        }
    }
    
    /* Update the hard cost of H1 and H2, considering the solution has already updated */
    private void validateH1andH2(int iDay, TypeJob job){        
        
        if(!job.isOFF()){
            int extraCost [] = new int[3];

            //H1 - Minimum number of physicians assigned to each day/shift/location
            extraCost[1] = -1 * costH1[iDay][job.ID];
            if(noAssign[iDay][job.ID] < sch.minAssign[iDay][job.ID]){
                costH1[iDay][job.ID] = weightHC * (sch.minAssign[iDay][job.ID] - noAssign[iDay][job.ID]);
                extraCost[1] += costH1[iDay][job.ID];
            }
            else costH1[iDay][job.ID] = 0;

            //H2 - Maximum number of physicians assigned to each day/shift/location
            extraCost[2] = -1 * costH2[iDay][job.ID];
            if(noAssign[iDay][job.ID] > sch.maxAssign[iDay][job.ID]){
                costH2[iDay][job.ID] = weightHC * (noAssign[iDay][job.ID] - sch.maxAssign[iDay][job.ID]);
                extraCost[2] += costH2[iDay][job.ID];
            }
            else costH2[iDay][job.ID] = 0;

            //Update the combined costs
            for(int i=1; i<=2; i++){
                costHARD    += extraCost[i];
                cost        += extraCost[i];
            }
        }
    }
    
    /* Update the hard cost of H8, considering the solution has already updated */
    private void validateH8(Physician phys, DayMonth day, TypeJob newJob){
        
        int iDay = day.ID;
        int iPhys = phys.ID;        

        //########################################################## CURRENT DAY
        if(iDay > 1){
            int extraCostCURR = -1 * costH8[iPhys][iDay];

            //If day before was assigned with NIG and the current day was assigned with DAY, MOR or AFT
            if(assignJob[iPhys][iDay-1].hasNigShifts() && newJob.hasDayShifts()){
                costH8[iPhys][iDay] = weightHC;
                extraCostCURR += costH8[iPhys][iDay];
            }
            else costH8[iPhys][iDay] = 0;

            costHARD    += extraCostCURR;
            cost        += extraCostCURR;
        }
        
        //############################################################# NEXT DAY
        if(iDay < sch.noDays){
            int extraCostNEXT = -1 * costH8[iPhys][iDay+1];

            //If the current day was assigned with NIG and the next day was assigned with DAY, MOR or AFT
            if(newJob.hasNigShifts() && assignJob[iPhys][iDay+1].hasDayShifts()){
                costH8[iPhys][iDay+1] = weightHC;
                extraCostNEXT += costH8[iPhys][iDay+1];
            }
            else costH8[iPhys][iDay+1] = 0;
            
            costHARD    += extraCostNEXT;
            cost        += extraCostNEXT;
        }
    }
}
