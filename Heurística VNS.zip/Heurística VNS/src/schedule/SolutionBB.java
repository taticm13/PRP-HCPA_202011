/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package schedule;

import calendar.TypeJob;
import calendar.DayMonth;
import calendar.Shift;
import calendar.WeekDay;

/**
 *
 * @author Tatiana
 */
public class SolutionBB {
    public Schedule sch;
    public boolean forcedStop;
    public double timeInit;
    public double runTime;
    public double timeLimit = 600;      //10 minutes
    public int noSolutions;
    
    //###################################### INFORMATION ABOUT THE BEST SOLUTION
    public int bestCost;                //                                  Cost of the best solution
    public int best_costSC[];           //[per Constraint]                  Total cost of each soft constraint
    public TypeJob[][] best_assignJob;  //[per Physician, per Day]          Job assigned for each day
    
    //################################### INFORMATION ABOUT THE CURRENT SOLUTION
    public int cost;                    //Cost of the CURRENT solution
    public int aHours_total[];          //[per Physician]                   Number of hours assigned in the CURRENT solution
    public int aHours_nWrkD_allSh[];    //[per Physician]                   Number of hours assigned on not working days in the CURRENT solution
    public int aHours_nWrkD_dayShs[];   //[per Physician]                   Number of hours assigned in day shifts of not working days in the CURRENT solution
    public int aHours_nWrkD_nigShs[];   //[per Physician]                   Number of hours assigned in night shifts of not working days in the CURRENT solution
    public int aHours_perLoc[][];       //[per Physician, per Location]     Number of hours assigned in each location in the CURRENT solution
    public int noAssigns_perWKND[][];   //[per Physician, per Week]         Number of assignments in each weekend in the CURRENT solution
    public int noAssigned_WKND[];       //[per Physician]                   Number of weekends assigned in the CURRENT solution
    public int consecNight[][];         //[per Physician, per Day]          Number of consecutive night shifts in the CURRENT solution
    public TypeJob[][] assignJob;       //[per Physician, per Day]          Job assigned for each day in the CURRENT solution
    public int noAssign[][];            //[per Day, per Job]                Number of physicians assigned to the DSL in the CURRENT solution
    public int noFixed [][];            //[per Day, per Job]                Number of fixed physician to assigned
    public boolean isPhysAvail[][][];   //[per Day, per Job, per Physician] Indicates if the physician is available or not for the DSL
    public int noAvailPhys[][];         //[per Day, per Job]                Number of available physicians
    
    //####################################### INFORMATION ABOUT SOFT CONSTRAINTS
    public int noSoftC;    
    public int weightSC[];              //[per Constraint]                  Weight of each soft constraint
    public int costSC[];                //[per Constraint]                  Total cost of each soft constraint
    
    //Increasing cost per physician
    public int costS1[];                //[per Physician]                   Minimum number of working hours
    public int costS2[][];              //[per Physician, per Day]          Maximum number of working hours
    public int costS3[];                //[per Physician]                   Minimum number of working hours on non-working days
    public int costS4[][];              //[per Physician, per Day]          Maximum number of working hours on non-working days
    public int costS5[];                //[per Physician]                   Balance of hours on non-working days
    public int costS6[][];              //[per Physician, per Week]         Incomplete weekend
    public int costS7[][];              //[per Physician, per Day]          Maximum number of weekends assigned
    public int costS8[][];              //[per Physician, per Day]          Maximum number of consecutive night shifts
    public int costS9[][];              //[per Physician, per Day]          Location non-preferential
    public int costS10[][];             //[per Physician, per Day]          Day/Shift non-preferential
    
    public SolutionBB(Schedule infoSch){
        sch = infoSch;
        
        //BEST solution
        bestCost            = -1;
        best_assignJob      = new TypeJob[sch.noPhys+1][sch.noDays+1];
        
        //CURRENT solution
        cost = 0;
        aHours_total        = new int[sch.noPhys+1];
        aHours_nWrkD_allSh  = new int[sch.noPhys+1];
        aHours_nWrkD_dayShs = new int[sch.noPhys+1];
        aHours_nWrkD_nigShs = new int[sch.noPhys+1];
        aHours_perLoc       = new int[sch.noPhys+1][sch.noLocs+1];
        noAssigns_perWKND   = new int[sch.noPhys+1][sch.noWeeks+1];
        noAssigned_WKND     = new int[sch.noPhys+1];
        consecNight         = new int[sch.noPhys+1][sch.noDays+1];
        assignJob           = new TypeJob[sch.noPhys+1][sch.noDays+1];
        noAssign            = new int[sch.noDays+1][sch.noJobs+1];
        isPhysAvail         = new boolean[sch.noDays+1][sch.noJobs+1][sch.noPhys+1];
        noAvailPhys         = new int[sch.noDays+1][sch.noJobs+1];
        
        //Initialization of "noFixed"
        noFixed = sch.noFixed.clone();
        
        //Initialization of "isPhysAvail" and "noAvailPhys"
        for(int iPhys=1; iPhys<=sch.noPhys; iPhys++){
            Physician phys = sch.phys[iPhys];
            for(int iDay=1; iDay<=sch.noDays; iDay++){
                for(int iJob=1; iJob<=sch.noJobs; iJob++){
                    if(phys.allowPreProc_job[iDay][iJob]){
                        isPhysAvail[iDay][iJob][iPhys] = true;
                        noAvailPhys[iDay][iJob]++;
                    }
                }
            }
        }
        
        //Initialization of the soft contraints
        noSoftC = 10;        
        weightSC = new int[noSoftC+1];            
            weightSC[1]     = 20;
            weightSC[2]     = 20;
            weightSC[3]     = 15;
            weightSC[4]     = 15;
            weightSC[5]     = 15;
            weightSC[6]     = 30;
            weightSC[7]     = 30;
            weightSC[8]     = 15;
            weightSC[9]     = 1;
            weightSC[10]    = 1;
            
        costSC = new int[noSoftC+1];
        best_costSC = new int[noSoftC+1];
        
        //Initialization of the variables
        costS1  = new int[sch.noPhys+1];
        costS2  = new int[sch.noPhys+1][sch.noDays+1];
        costS3  = new int[sch.noPhys+1];
        costS4  = new int[sch.noPhys+1][sch.noDays+1];
        costS5  = new int[sch.noPhys+1];
        costS6  = new int[sch.noPhys+1][sch.noWeeks+1];
        costS7  = new int[sch.noPhys+1][sch.noDays+1];
        costS8  = new int[sch.noPhys+1][sch.noDays+1];
        costS9  = new int[sch.noPhys+1][sch.noDays+1];
        costS10 = new int[sch.noPhys+1][sch.noDays+1];
    }
    
/*  ## AUXILIAR FUNCTIONS ################################################### */
    /* Return TRUE if it was achieved the time limit, stopping the algorithm */
    public boolean timeLimit(){
        runTime = (double)(System.currentTimeMillis()-timeInit)/1000;
        if(runTime > timeLimit){
            forcedStop = true;
            return true;
        }
        else return false;
    }
    
    /* Update the best solution when achieves a complete solution with better cost */
    public void update_bestSolution(){
        noSolutions++;
        
        if(bestCost == -1 || cost < bestCost){
            bestCost = cost;            
            for(int i=1; i<=noSoftC; i++){
                best_costSC[i] = costSC[i];
            }
            
            for(int iPhys=1; iPhys<=sch.noPhys; iPhys++){
                for(int iDay=1; iDay<=sch.noDays; iDay++){
                    best_assignJob[iPhys][iDay] = assignJob[iPhys][iDay];
                }
            }
        }
    }
    
    /* Return the ASSIGN if the job is allowed for the physician on the day, considering the current solution */
    public Assign assignOf_JobAllowed(DayMonth day, Physician phys, TypeJob job){
        
        //Consider the hard Constraints
        if(!isJobAllowed(day,phys,job)){
            return null;
        }
                
        if(!isJobAllowedMAX(day,phys,job)){
            return null;
        }
        
        int difMin =        sch.minAssign[day.ID][job.ID]
                        -   noAssign[day.ID][job.ID]
                        -   noFixed[day.ID][job.ID];
        difMin     =    Math.max(0,difMin);
        
        int difMax =        sch.maxAssign[day.ID][job.ID]
                        -   noAssign[day.ID][job.ID]
                        -   noFixed[day.ID][job.ID];
        difMax     =    Math.max(0,difMax);
        
        int noAvail =   noAvailPhys[day.ID][job.ID];
        
        Assign assign = new Assign(phys,day,job,difMin,difMax,noAvail);
        
        //Consider soft constraints and validates the cost
        if(saveAssign(assign)){
            undoAssign(day.ID,phys.ID);
            return assign;
        }
        else{
            return null;
        }
    }
    
    /* Return TRUE if the job is allowed for the physician on the day, considering the current solution */
    private boolean isJobAllowed(DayMonth day, Physician phys, TypeJob job){
        
        //Considers the assigment in ascending order of days, taking into account:
        
        //Hard Constraints
        if(phys.fixedJob[day.ID]==null || phys.fixedJob[day.ID].ID != job.ID){
            /*  - [allowPreProc_job] The fixed assignments on the actual, previous and next days
                - [allowPreProc_job] The lock assignments on the actual day
                - [allowPreProc_job] The allowed jobs for the physician
                - [allowPreProc_job] The allowed shifts considering the type of the day (working day or not)    */
            if(!phys.allowPreProc_job[day.ID][job.ID]) return false;
            
            if(!job.isOFF()){
                /*  - The invalid succession of shifts on consecutive days of the current solution                  */
                if(day.ID > 1 && assignJob[phys.ID][day.ID-1]!=null && job.hasDayShifts() && assignJob[phys.ID][day.ID-1].hasNigShifts()) return false;
                
                /*  - The maximum number of physicians can be assigned to the job (with fixed)                      */
                /*if(     noAssign[day.ID][job.ID] + noFixed[day.ID][job.ID]
                    >=  sch.maxAssign[day.ID][job.ID]) return false;   */
            }
        }
        
        return true;
    }
    
    /* Return TRUE if the job is allowed for the physician on the day, considering the maximum demand */
    private boolean isJobAllowedMAX(DayMonth day, Physician phys, TypeJob job){
        if(phys.fixedJob[day.ID]==null || phys.fixedJob[day.ID].ID != job.ID){
            if(     noAssign[day.ID][job.ID] + noFixed[day.ID][job.ID]
                    >=  sch.maxAssign[day.ID][job.ID]) return false;
        }
        return true;
    }
    
    /* Return TRUE if removing the physician, the DSL is still feasible considering the minimum demand */
    private boolean removeAvail(int iDay, int iJob, int iPhys){
       
        if(sch.jobs[iJob].isJobValid(sch.days[iDay])){
            if(isPhysAvail[iDay][iJob][iPhys]){
                isPhysAvail[iDay][iJob][iPhys] = false;
                noAvailPhys[iDay][iJob]--;
            }

            return noAvailPhys[iDay][iJob] + noAssign[iDay][iJob] >= sch.minAssign[iDay][iJob];
        }
        else return true;
    }
    
    /* Turns the physician available for the DSL, if allowed */
    private void addAvail(int iDay, int iJob, int iPhys){
        if(!isPhysAvail[iDay][iJob][iPhys] && isJobAllowed(sch.days[iDay],sch.phys[iPhys],sch.jobs[iJob])){
            isPhysAvail[iDay][iJob][iPhys] = true;
            noAvailPhys[iDay][iJob]++;
        }
    }
    
    
/*  ## ASSIGN PHYSICIAN ##################################################### */
    /*  Save the assignment in the current solution.
        Return TRUE if no infeasibility was found.
        Return FALSE and BACK the previous state of solution, otherwise.    */
    public boolean saveAssign(Assign assign){
        
        int iPhys   = assign.phys.ID;
        int iDay    = assign.day.ID;
        TypeJob job = assign.job;
        
        //Check if the physician is available
        if(!isPhysAvail[iDay][job.ID][iPhys]){
            System.out.println(">> iDay="+iDay+" iJob="+job.ID+" iPhys"+iPhys+" iShift="+job.shift+" iLoc="+job.loc);
            System.out.println("ERROR - saveAssign - PHYSICIAN NOT AVAILABLE");
            for(int i=1; i<iDay; i++){
                System.out.println("iDay="+i+", shiftAssign="+assignJob[iPhys][i].shift);
            }
            System.exit(0);
            return false;
        }
        
        if(!isJobAllowedMAX(assign.day,assign.phys,job)){
            return false;
        }
        
        //########################################## UPDATE THE CURRENT SOLUTION
        //Assignment of the day
        assignJob[iPhys][iDay] = job;
        
        //Number of assignments
        noAssign[assign.day.ID][job.ID]++;

        //Number of fixed physicians to assign
        if(assign.phys.fixedJob[iDay]!=null && assign.phys.fixedJob[iDay].ID == job.ID){
            noFixed[assign.day.ID][job.ID]--;
        }    
        
        
        //######################## UPDATE AVAILABILITY AND CHECK THE FEASIBILITY
        //Remove the availability of the physician in all jobs of the current day
        for(int iJob=1; iJob<=sch.noJobs; iJob++){
            if(!removeAvail(iDay,iJob,iPhys)){
                //**UNDO - Current day**\\
                for(int kJob=iJob; kJob>=1; kJob--){
                    addAvail(iDay,kJob,iPhys);
                }
                
                assignJob[iPhys][iDay] = null;
                noAssign[assign.day.ID][job.ID]--;
                if(assign.phys.fixedJob[iDay]!=null && assign.phys.fixedJob[iDay].ID == job.ID){
                    noFixed[assign.day.ID][job.ID]++;
                }
            
                return false;
            }
        }
        
        //Remove the availability of the physician in jobs with day shifts of the next day, if the current job has night shifts
        if(job.hasNigShifts() && iDay < sch.noDays){
            
            for(int iJob=1; iJob<=sch.noJobs; iJob++){
                if(sch.jobs[iJob].hasDayShifts()){
                    if(!removeAvail(iDay+1,iJob,iPhys)){
                        //**UNDO - Current Day**\\
                        for(int kJob=1; kJob<=sch.noJobs; kJob++){
                            addAvail(iDay,kJob,iPhys);
                        }
                        //**UNDO - Next Day**\\
                        for(int kJob=iJob; kJob>=1; kJob--){
                            if(sch.jobs[kJob].hasDayShifts()){
                                addAvail(iDay+1,kJob,iPhys);
                            }
                        }
                        
                        assignJob[iPhys][iDay] = null;
                        noAssign[assign.day.ID][job.ID]--;
                        if(assign.phys.fixedJob[iDay]!=null && assign.phys.fixedJob[iDay].ID == job.ID){
                            noFixed[assign.day.ID][job.ID]++;
                        }
                
                        
                        return false;
                    }
                }
            }
        }   
                
        //####################################### UPDATE THE AUXILIAR STRUCTURES
        //Total number of hours
        aHours_total[iPhys] += job.noHours();
        
        //Number of hours on not working hours
        if(!assign.day.isWorkDay){
            aHours_nWrkD_allSh[iPhys] += job.noHours();
            
            if(job.hasDayShifts()) aHours_nWrkD_dayShs[iPhys] += job.noHours();
            else aHours_nWrkD_nigShs[iPhys] += job.noHours();
        }
        
        //Number of hours in the location
        aHours_perLoc[iPhys][job.loc] += job.noHours();
        
        //Number of assignments in each weekend
        if(!job.isOFF() && assign.day.isWKND){
            noAssigns_perWKND[iPhys][assign.day.week]++;
            
            //Number of assigned weekends
            if(noAssigns_perWKND[iPhys][assign.day.week] == 1){
                noAssigned_WKND[iPhys]++;
            }
        }
        
        //Consecutive nights assigned
        if(job.hasNigShifts()){
            if(assign.day.ID > 1){
                consecNight[iPhys][assign.day.ID] = consecNight[iPhys][assign.day.ID-1] + 1;
            }
            else consecNight[iPhys][assign.day.ID] = 1;
        }
        
        return updateCost_assign(assign);
    }
    
    /* Return TRUE and update the current cost if above the best solution cost.
       Return FALSE and undo the updates in the cost and assignment structures, otherwise. */
    public boolean updateCost_assign(Assign assign){
        
        int prevCost = cost;
        
        int iDay = assign.day.ID;
        int iPhys = assign.phys.ID;
        int iWeek = assign.day.week;
        TypeJob job = assign.job;
        
        //######################################################################
        //S1 - Minimum number of working hours
        if(iDay == sch.noDays){
            if(aHours_total[iPhys] < assign.phys.workload){
                costS1[iPhys] = weightSC[1]* (assign.phys.workload - aHours_total[iPhys]);
                
                cost      += costS1[iPhys];
                costSC[1] += costS1[iPhys];
            }
        }
        
        //######################################################################
        //S2 - Maximum number of working hours 
        if(job.shift != Shift.OFF){
            if(aHours_total[iPhys] > assign.phys.workload){
                costS2[iPhys][iDay] = weightSC[2] * Math.min(aHours_total[iPhys] - assign.phys.workload, job.noHours());
                
                cost      += costS2[iPhys][iDay];
                costSC[2] += costS2[iPhys][iDay];
            }
        }
        
        //######################################################################
        //S3 - Minimum number of working hours on non-working days
        if(iDay == sch.noDays){
            if(aHours_nWrkD_allSh[iPhys] < assign.phys.idealHours_nWrkD){
                costS3[iPhys] = weightSC[3]* (assign.phys.idealHours_nWrkD - aHours_nWrkD_allSh[iPhys]);
                
                cost      += costS3[iPhys];
                costSC[3] += costS3[iPhys];
            }
        }
        
        //######################################################################
        //S4 - Maximum number of working hours on non-working days
        if(job.shift != Shift.OFF && !assign.day.isWorkDay){
            if(aHours_nWrkD_allSh[iPhys] > assign.phys.idealHours_nWrkD){
                costS4[iPhys][iDay] = weightSC[4] * Math.min(aHours_nWrkD_allSh[iPhys] - assign.phys.idealHours_nWrkD, job.noHours());
                
                cost      += costS4[iPhys][iDay];
                costSC[4] += costS4[iPhys][iDay];
            }
        }
        
        //######################################################################
        //S5 - Balance of hours on non-working days
        if(iDay == sch.noDays){
            costS5[iPhys] = weightSC[5]* Math.abs(aHours_nWrkD_dayShs[iPhys] - aHours_nWrkD_nigShs[iPhys]);
                
            cost      += costS5[iPhys];
            costSC[5] += costS5[iPhys];
        }
        
        //######################################################################
        //S6 - Incomplete weekend
        if(assign.day.dayWeek == WeekDay.SUNDAY && noAssigns_perWKND[iPhys][iWeek] == 1){
            costS6[iPhys][iWeek] = weightSC[6];
                
            cost      += costS6[iPhys][iWeek];
            costSC[6] += costS6[iPhys][iWeek];
        }
        
        //######################################################################
        //S7 - Maximum number of weekends assigned
        if(job.shift != Shift.OFF && assign.day.isWKND && noAssigned_WKND[iPhys] > 2){
            if(noAssigns_perWKND[iPhys][iWeek] == 1){
                costS7[iPhys][iDay] = weightSC[7];
                
                cost      += costS7[iPhys][iDay];
                costSC[7] += costS7[iPhys][iDay];
            }
        }
        
        //######################################################################
        //S8 - Maximum number of consecutive night shifts
        if(job.shift == Shift.NIG && consecNight[iPhys][iDay] > 3){
            costS8[iPhys][iDay] = weightSC[8];
                
            cost      += costS8[iPhys][iDay];
            costSC[8] += costS8[iPhys][iDay];
        }
        
        //######################################################################
        //S9 - Location non-preferential
        if(assign.phys.locNonPref[job.loc]){
            costS9[iPhys][iDay] = weightSC[9] * job.noShifts();
                
            cost      += costS9[iPhys][iDay];
            costSC[9] += costS9[iPhys][iDay];
        }
        
        //######################################################################
        //S10 - Day/Shift non-preferential
        if(assign.phys.penaltyAssign[iDay][job.shift.index] > 0){
            costS10[iPhys][iDay] = weightSC[10] * assign.phys.penaltyAssign[iDay][job.shift.index];
                
            cost      += costS10[iPhys][iDay];
            costSC[10] += costS10[iPhys][iDay];
        }
        
        //Check if the cost is lower than the best
        if(bestCost == -1 || cost < bestCost){
            assign.addCost = cost - prevCost;
            return true;
        }
        else{
            undoAssign(iDay,iPhys);
            return false;
        }
    }
    
/*  ## UNASSIGN PHYSICIAN ################################################### */
    /*  Undo the assignment of a physician */
    public void undoAssign(int iDay, int iPhys){
        
        TypeJob job     = assignJob[iPhys][iDay];
        Physician phys  = sch.phys[iPhys];
        DayMonth day    = sch.days[iDay];
        
        if(assignJob[iPhys][iDay] == null) return;
        
        //Update the cost
        updateCost_unassign(iDay,iPhys);
        
        //########################################## UPDATE THE CURRENT SOLUTION
        //Number of assignments
        noAssign[iDay][job.ID]--;

        //Number of fixed physicians to assign
        if(phys.fixedJob[iDay]!=null && phys.fixedJob[iDay].ID == job.ID){
            noFixed[iDay][job.ID]++;
        }  
        
        //Assignment of the day
        assignJob[iPhys][iDay] = null;  
        
        //################################################## UPDATE AVAILABILITY
        //Check the availability of the current day
        for(int iJob=1; iJob<=sch.noJobs; iJob++){
            addAvail(iDay,iJob,iPhys);
        }
        
        //Check the availability of the next day, if the current job has night shifts
        if(job.hasNigShifts() && iDay < sch.noDays){
            for(int iJob=1; iJob<=sch.noJobs; iJob++){
                if(sch.jobs[iJob].hasDayShifts()){
                    addAvail(iDay+1,iJob,iPhys);
                }
            }
        }     
        
        //####################################### UPDATE THE AUXILIAR STRUCTURES
        //Total number of hours
        aHours_total[iPhys] -= job.noHours();
        
        //Number of hours on not working hours
        if(!day.isWorkDay){
            aHours_nWrkD_allSh[iPhys] -= job.noHours();
            
            if(job.hasDayShifts()) aHours_nWrkD_dayShs[iPhys] -= job.noHours();
            else aHours_nWrkD_nigShs[iPhys] -= job.noHours();
        }
        
        //Number of hours in the location
        aHours_perLoc[iPhys][job.loc] -= job.noHours();
        
        //Number of assignments in each weekend
        if(!job.isOFF() && day.isWKND){
            noAssigns_perWKND[iPhys][day.week]--;
            
            //Number of assigned weekends
            if(noAssigns_perWKND[iPhys][day.week] == 0){
                noAssigned_WKND[iPhys]--;
            }
        }
        
        //Consecutive nights assigned
        if(job.hasNigShifts()) consecNight[iPhys][iDay] = 0;
        
    }
    
    /* Undo the updates in the cost structures */
    public void updateCost_unassign(int iDay, int iPhys){
        
        int iWeek = sch.days[iDay].week;
        
        int reduce[] = new int[noSoftC+1];
        
        //######################################################################
        //S1 - Minimum number of working hours
        reduce[1]       = costS1[iPhys];
        costS1[iPhys]   = 0;
        
        //######################################################################
        //S2 - Maximum number of working hours
        reduce[2]           = costS2[iPhys][iDay];
        costS2[iPhys][iDay] = 0;   
        
        //######################################################################
        //S3 - Minimum number of working hours on non-working days
        reduce[3]       = costS3[iPhys];
        costS3[iPhys]   = 0;
        
        //######################################################################
        //S4 - Maximum number of working hours on non-working days
        reduce[4]           = costS4[iPhys][iDay];
        costS4[iPhys][iDay] = 0;   
        
        //######################################################################
        //S5 - Balance of hours on non-working days
        reduce[5]       = costS5[iPhys];
        costS5[iPhys]   = 0;
        
        //######################################################################
        //S6 - Incomplete weekend
        reduce[6]               = costS6[iPhys][iWeek];
        costS6[iPhys][iWeek]    = 0;
        
        //######################################################################
        //S7 - Maximum number of weekends assigned
        reduce[7]               = costS7[iPhys][iDay];
        costS7[iPhys][iDay]    = 0;
        
        //######################################################################
        //S8 - Maximum number of consecutive night shifts
        reduce[8]               = costS8[iPhys][iDay];
        costS8[iPhys][iDay]    = 0;
        
        //######################################################################
        //S9 - Location non-preferential
        reduce[9]               = costS9[iPhys][iDay];
        costS9[iPhys][iDay]    = 0;
        
        //######################################################################
        //S10 - Day/Shift non-preferential
        reduce[10]               = costS10[iPhys][iDay];
        costS10[iPhys][iDay]    = 0;        
        
        //Update the compiled information
        for(int i=1; i<=noSoftC; i++){
            costSC[i]   -= reduce[i];
            cost        -= reduce[i];
        }        
    }
}
