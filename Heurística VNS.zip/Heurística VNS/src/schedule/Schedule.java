/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package schedule;

import calendar.TypeJob;
import calendar.DayMonth;
import calendar.WeekDay;
import file.BuildInstance;

/**
 *
 * @author Tatiana
 */
public class Schedule {
    
    public String versionAlg;
    public String versionIns;
    public String instPath;
    public String instName;
    public String solPath;
    
    //Information about the calendar
    public int month;
    public int year;    
    public int noDays;
    public int noWeeks;    
    public WeekDay firstDayWeek;
    public WeekDay lastDayWeek; 
    public DayMonth days[]; //per Day
    
    //Information about the hospital
    public int noLocs;
    public int noPhys;
    public Physician phys[];
    public int noJobs;
    public TypeJob jobs[];
    public int jobID[][]; //per Shift, per Location
    
    //Demand information
    public int minAssign [][];    //per Day, per Job
    public int maxAssign [][];    //per Day, per Job
    public int noFixed [][];      //per Day, per Job
    
    public Schedule(String info_instPath, String info_instName, String info_solPath){
        instPath = info_instPath;
        instName = info_instName;
        solPath  = info_solPath;
        
        new BuildInstance(this);
    }
}
