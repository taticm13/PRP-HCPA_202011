/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package schedule;

import calendar.TypeJob;
import calendar.DayMonth;

/**
 *
 * @author Tatiana
 */
public class Assign {
    public Physician phys;
    public DayMonth day;    
    public TypeJob job;
    
    public int addCost; //Cost increase with this assignment
    public int difMin;  //Number of physician missing in the job to achieve the minimum required
    public int difMax;  //Number of physician missing in the job to achieve the maximum required
    public int noAvail;
    
/*  ## INITIALIZATION ####################################################### */
    public Assign(){
        
    }
    
    /* Used with the Branch & Bound algorithm */
    public Assign(Physician infoPhys, DayMonth infoDay, TypeJob infoJob, int infoDifMin, int infoDifMax, int infoAvail){
        phys    = infoPhys;
        day     = infoDay;
        job     = infoJob;
        addCost = 0;            //Updated during the saving method
        difMin  = infoDifMin;
        difMax  = infoDifMax;
        noAvail = infoAvail;
    }
    
    /* Used with the Heuristic algorithm */
    public Assign(Physician infoPhys, DayMonth infoDay, TypeJob infoJob, int infoAddCost){
        phys    = infoPhys;
        day     = infoDay;
        job     = infoJob;
        addCost = infoAddCost;
        difMin  = 0;
        difMax  = 0;
    }
    
    public void init(Physician infoPhys, DayMonth infoDay, TypeJob infoJob){
        phys    = infoPhys;
        day     = infoDay;
        job     = infoJob;
        addCost = 0;
        difMin  = 0;
        difMax  = 0;
    }
    
    public void copy(Assign origin){
        phys    = origin.phys;
        day     = origin.day;
        job     = origin.job;
        addCost = origin.addCost;
    }
}
