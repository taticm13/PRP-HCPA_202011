/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package schedule;

import calendar.TypeJob;
import calendar.Shift;

/**
 *
 * @author Tatiana
 */
public class Physician {
    
    public int ID;
    public String name;
    
    public int workload;
    public int idealHours_nWrkD;
    
    public boolean locAllowed[];    //per Location
    public boolean locNonPref[];    //per Location
    
    public TypeJob fixedJob[];       //per Day
    public boolean isLock[][];      //per Day, per Shift    
    public int penaltyAssign[][];   //per Day, per Shift
    
    public boolean allowPreProc_job[][];    //per Day, per Job
    public boolean allowPreProc_shift[][];  //per Day, per Shift
    public boolean allowPreProc_loc[][];    //per Day, per Location
    
    
    public Physician(int noDays, int noLocs, int noJobs){
        locAllowed      = new boolean[noLocs+1];
        locNonPref      = new boolean[noLocs+1];        
        fixedJob        = new TypeJob[noDays+1];
        isLock          = new boolean[noDays+1][Shift.get_qtyTypes()+1];
        penaltyAssign   = new int[noDays+1][Shift.get_qtyTypes()+1];
        
        allowPreProc_job    = new boolean [noDays+1][noJobs+1];
        allowPreProc_shift  = new boolean [noDays+1][Shift.get_qtyTypes()+1];
        allowPreProc_loc    = new boolean [noDays+1][noLocs+1];
    }
}
