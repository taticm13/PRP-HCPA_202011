/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prp;

import algorithms.SI_BBT;
import java.io.File;
import schedule.Schedule;

/**
 *
 * @author Tatiana
 */
public class PRP {

    public static String inst_path    = "Instances\\";
    public static String sol_path     = "Solutions\\";
            
    public static void main(String[] args) {
        
        String groupGen         = "12";
        String l_group[]        = new String[]{"BD","MD","AD"};
        int l_noPhys[]          = new int[]{50,100,150,250,500};
        int l_noLoc[]           = new int[]{4};
        String tID[]            = new String[]{"1","2","3"};
        boolean tF1_sort[]      = new boolean[]{false};
        boolean tF2_localS[]    = new boolean[]{true};
        int maxExec             = 10;
        
        //Creation of solution folder
        String folderSol    = sol_path+"Group "+groupGen+"\\";
        new File(folderSol).mkdir();
        
        String folderInst = inst_path+"\\Group "+groupGen+"\\";
             
        for(String group : l_group){
            for(String ID : tID){
                for(int noPhys : l_noPhys){
                    for(int noLoc : l_noLoc){
                        for(int j=0; j<tF2_localS.length; j++){
                            for(int iExec=1; iExec<=maxExec; iExec++){
                                boolean withSort = tF1_sort[j];
                                boolean withLS   = tF2_localS[j];
                                
                                String inst_name = "I_"+group+"_"+noPhys+"P_"+noLoc+"L_ID"+ID;

                                folderSol = sol_path+"Group "+groupGen+"\\"+inst_name.replace("I_", "S_")+"\\";
                                new File(folderSol).mkdir();
                                inst_name += ".txt";

                                //Building of the Instance Schedule
                                Schedule sch = new Schedule(folderInst,inst_name,folderSol);

                                //OUTPUT
                                System.out.print(groupGen+";"+group+";"+sch.noPhys+";"+sch.noLocs+";ID"+ID+";"+iExec+";");
                                new SI_BBT(sch,iExec,withSort,withLS);
                                System.out.println("");
                            }
                        }
                    }
                }
            }
        }
    }    
}
