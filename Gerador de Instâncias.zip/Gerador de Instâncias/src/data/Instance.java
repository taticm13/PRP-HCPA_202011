/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package data;

import java.util.ArrayList;
import java.util.Calendar;

/**
 *
 * @author Tatiana
 */
public class Instance {
    
    public int month;
    public int year;
    public int firstDay;
    public int lastDay;
    public int noDays;
    
    public int noLocs;
    public int noPhys;
    
    public int[] holidays;
    public ArrayList<Physician> physicians;
    
    public ArrayList<FixedAssign> fixedAssigns;
    public ArrayList<Lock> locks;
    public ArrayList<PenaltyAssign> notPrefWDSh;
    public ArrayList<NotPrefLoc> notPrefLoc;

    public int [][][] minAssign;    //per Day, per Shift, per Location
    public int [][][] maxAssign;    //per Day, per Shift, per Location
    public int [][][] fixedAssign;  //per Day, per Shift, per Location
    
    public int noRequirements;
    
    public Instance(){
        physicians = new ArrayList<>();
        fixedAssigns = new ArrayList<>();      
        locks = new ArrayList<>();
        notPrefWDSh = new ArrayList<>();
        notPrefLoc = new ArrayList<>();
    }
    
    public void setMonth(int month, int year){
        Calendar calendar = Calendar.getInstance();
        
        calendar.set(Calendar.YEAR, year);
        calendar.set(Calendar.MONTH, month-1);
        
        this.month = month;
        this.year = year;
        this.firstDay = 1;
        this.lastDay = calendar.getActualMaximum(Calendar.DAY_OF_MONTH);  
        
        noDays = lastDay - firstDay + 1;
    }
    
    public boolean isWorkDay(int day){
        Calendar calendar = Calendar.getInstance();
        
        calendar.set(Calendar.YEAR, year);
        calendar.set(Calendar.MONTH, month-1);
        calendar.set(Calendar.DAY_OF_MONTH,day);
        
        switch (calendar.get(Calendar.DAY_OF_WEEK)) {
            case Calendar.SUNDAY:
                return false;
            case Calendar.SATURDAY:
                return false;
            default:
                for(int i=0; i<holidays.length; i++){
                    if(holidays[i] == day) return false;
                }
                return true;
        }
    }
}
