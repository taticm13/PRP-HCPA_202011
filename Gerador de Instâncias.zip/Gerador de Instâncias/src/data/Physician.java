/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package data;

public class Physician {
    
    public int ID;
    public int workload;
    public int idealHours_notWorkDay;
    public boolean allowLoc[];
    public int noAllowedLocs;
    
    public boolean[] vacation;      //per Day
    public boolean[] lock;          //per Day
        
    public boolean fixed[];         //per Day
    public boolean assignNight[];   //per Day
    
    
    public Physician(int ID, int noLocs){
        this.ID = ID;
        
        allowLoc = new boolean[noLocs+1];
        
        vacation = new boolean[32];
        lock = new boolean[32];
        fixed = new boolean[32];
        assignNight = new boolean[32];
    }    
}
 
