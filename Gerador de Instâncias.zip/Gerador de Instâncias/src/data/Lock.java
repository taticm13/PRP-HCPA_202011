/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package data;

/**
 *
 * @author Tatiana
 */
public class Lock {
    public int phys;
    public int day;
    public int shift;

    public Lock(int aPhys, int aWD, int aShift){
        phys = aPhys;
        day = aWD;
        shift = aShift;
    }
}
