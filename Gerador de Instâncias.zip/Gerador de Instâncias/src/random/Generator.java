/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package random;

import data.FixedAssign;
import data.Instance;
import data.Lock;
import data.NotPrefLoc;
import data.PenaltyAssign;
import data.Physician;
import java.util.Random;

/**
 *
 * @author Tatiana
 */
public class Generator {
    
    private final int holidaysPerMonth [][];
    private Random rnd;
    
    public Generator(){
        
        rnd = new Random();
        
        //National holidays (Brazil)
        holidaysPerMonth = new int[13][];
        
            holidaysPerMonth[1] = new int[]{1};
            holidaysPerMonth[2] = new int[]{};
            holidaysPerMonth[3] = new int[]{5};
            holidaysPerMonth[4] = new int[]{19,21};
            holidaysPerMonth[5] = new int[]{1};
            holidaysPerMonth[6] = new int[]{20};
            holidaysPerMonth[7] = new int[]{};
            holidaysPerMonth[8] = new int[]{};
            holidaysPerMonth[9] = new int[]{7,20};
            holidaysPerMonth[10] = new int[]{12};
            holidaysPerMonth[11] = new int[]{2,15};
            holidaysPerMonth[12] = new int[]{25};
    }
    
    public Instance createInstance(Parameters params){
        Instance inst = new Instance();
        
        /** ############################################## DAYS OF THE INSTANCE.
         * -Define the month and year */
        inst.setMonth(params.month,params.year);
        
        /**########################################################### HOLIDAYS.
         * - Define the days of the month that are holidays */
        inst.holidays = holidaysPerMonth[params.month];
        
        /** ######################################################### LOCATIONS.
         * - Define the number of locations */
        inst.noLocs = params.noLocs;
        
        /** ######################################################## PHYSICIANS.
         * - Define the number of physicians and the percentage in each type of contract
         * --> FULL time:       200 hours, 48h ideal non-business days
         * --> PARTIAL time:    150 hours, 24h ideal non-business days */
        createInst_physicians(inst,params);
        
        /** ############################################ LOCATIONS x PHYSICIANS.
         * - Define the percentage of unrestricted locations and
         *   the percentage of physicians who are allowed to other locations */
        createInst_locXphys(inst,params);
        
        /** ############################################################# LOCKS.
         * - Define the probability of a day/shift to be locked */
        createInst_locks(inst,params);
        
        /** ################################################# FIXED ASSIGNMENTS.
         * - Define the probability of a day/shift to be fixed to a location */
        createInst_fixed(inst,params);
        
        /** ############################### PHYSICIANS X PENALTY PER ASSIGNMENT.
         * - Define the probability of a day/shift to be non-preferential */
        createInst_nPrefDaysXphys(inst,params);
        
        /** ############################# PHYSICIANS X PREFERENCES PER LOCATION.
         * - Define the probability of the physician has not preference for the location */
        createInst_nPrefLocXphys(inst,params);
        
        /** ############################################################ DEMAND.
         *  Define the minimum and maximum interval for the minimum demand of physicians 
         *  Define the minimum and maximum interval for the maximum demand of physicians */
        createInst_requirements(inst,params);
        
        return inst;
    }
    
    private void createInst_physicians(Instance inst, Parameters params){
        inst.noPhys = params.noPhys;
        
        int partialTime = (int) (inst.noPhys * (double) params.workload_percParcial/100);
        int fullTime    = inst.noPhys - partialTime;  
        
        int noLow = 0, noHigh = 0;        
        for(int i=1; i<=inst.noPhys; i++){
            Physician phys = new Physician(i,inst.noLocs);
            
            int rndSel = rnd.nextInt(2)+1;
            
            if((rndSel == 1 && noLow < partialTime) || (rndSel == 2 && noHigh >= fullTime)) {
                phys.workload = 150;
                phys.idealHours_notWorkDay = 24;
                
                noLow++;
            }
            else if((rndSel == 2 && noHigh < fullTime) || (rndSel == 1 && noLow >= partialTime)){
                phys.workload = 200;
                phys.idealHours_notWorkDay = 48;
                
                noHigh++;
            }
            
            inst.physicians.add(phys);
        }
    }
    
    private void createInst_locXphys(Instance inst, Parameters params){
        int noLocsUnrestricted = (int) (inst.noLocs * (double) params.allowLoc_percUnrLocs/100);
        int probLoc[] = new int[inst.noLocs+1];

        for(int i=1; i<=inst.noLocs; i++){
            if(noLocsUnrestricted > 0){
                probLoc[i] = 100;
                noLocsUnrestricted--;
            }
            else probLoc[i] = params.allowLoc_percPhysPerm;
        }
        
        for(int i=0; i<inst.noPhys; i++){
            Physician phys = inst.physicians.get(i);

            for(int j=1; j<=inst.noLocs; j++){
                if(rnd.nextInt(100) <= probLoc[j]){
                    phys.allowLoc[j] = true;
                    phys.noAllowedLocs++;
                }
            }
        }    
    }
    
    private void createInst_locks(Instance inst, Parameters params){
        if(params.lock_probLockDS == 0) return;
        
        int noLocks = 0;
        
        boolean withMax = false;
        if(params.lock_max > 0) withMax = true;
        
        //Random locks on day/shifts
        for(int i=0; i<inst.noPhys; i++){
            Physician phys = inst.physicians.get(i);
            
            for(int day=inst.firstDay; day<=inst.lastDay; day++){
                //Only it locks a shift of the day, if the physician is not on vacations
                if(!phys.vacation[day] && inst.isWorkDay(day)){
                    
                    if(params.lock_allDay && rnd.nextInt(100) <= params.lock_probLockDS){
                        for(int iSh=1; iSh<=3; iSh++){
                            inst.physicians.get(i).lock[day] = true;
                            inst.locks.add(new Lock(phys.ID,day,iSh));
                            noLocks++;
                        }
                    }
                    else{
                        for(int iSh=1; iSh<=3; iSh++){
                            if(rnd.nextInt(100) <= params.lock_probLockDS){
                                inst.physicians.get(i).lock[day] = true;
                                inst.locks.add(new Lock(phys.ID,day,iSh));
                                noLocks++;
                            }
                        }
                    }
                }
                
                if(withMax && noLocks > params.lock_max) return;
            }
        }
    }
    
    private void createInst_fixed(Instance inst, Parameters params){
        if(params.fixed_prob == 0) return;
        
        inst.fixedAssign = new int[32][4][inst.noLocs+1];
        
        for(int j=inst.noPhys-1; j>=0; j--){
            Physician phys = inst.physicians.get(j);                
            int day = rnd.nextInt(inst.lastDay)+inst.firstDay;
            
            if(!phys.lock[day] && inst.isWorkDay(day)){ //If it is not a lock day
                if(!phys.vacation[day]){ //If it is not a vacation day
                    
                    int iShift = rnd.nextInt(2)+1;
                    int iLoc = rnd.nextInt(inst.noLocs)+1;
                    
                    if(phys.allowLoc[iLoc]){ //If the physician is allowed to the location
                        if(rnd.nextInt(100) <= params.fixed_prob){
                            if((iShift != 3 && !phys.assignNight[day-1]) || iShift == 3){ //If the assignment is valid
                                if(inst.isWorkDay(day)){
                                    phys.fixed[day] = true;
                                    inst.fixedAssigns.add(new FixedAssign(phys.ID,day,iShift,iLoc));
                                    inst.fixedAssign[day][iShift][iLoc]++;
                                    if(iShift == 3) phys.assignNight[day] = true;
                                }
                                else{
                                    if(iShift == 3){
                                        phys.fixed[day] = true;
                                        inst.fixedAssigns.add(new FixedAssign(phys.ID,day,iShift,iLoc));
                                        inst.fixedAssign[day][iShift][iLoc]++;
                                        phys.assignNight[day] = true;
                                    }
                                    else{
                                        phys.fixed[day] = true;
                                        inst.fixedAssigns.add(new FixedAssign(phys.ID,day,1,iLoc)); //SHIFT DAY = 1,2
                                        inst.fixedAssign[day][1][iLoc]++;
                                        phys.assignNight[day] = false;

                                        phys.fixed[day] = true;
                                        inst.fixedAssigns.add(new FixedAssign(phys.ID,day,2,iLoc)); //SHIFT DAY = 1,2
                                        inst.fixedAssign[day][2][iLoc]++;
                                        phys.assignNight[day] = false;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    
    public void createInst_nPrefDaysXphys(Instance inst, Parameters params){
        
        for(int i=0; i<inst.noPhys; i++){
            Physician phys = inst.physicians.get(i);
            for(int day=inst.firstDay; day<=inst.lastDay; day++){
                if(!phys.lock[day] && !phys.vacation[day] && !phys.fixed[day]){ //If it is not a lock day, neither a vacation day, neither a fixed day
                    for(int iSh=1; iSh<=3; iSh++){
                        if(rnd.nextInt(100) <= params.probNPref){
                            inst.notPrefWDSh.add(new PenaltyAssign(i+1,day,iSh,1));
                        }
                    }
                }
            }
        }
    }
    
    public void createInst_nPrefLocXphys(Instance inst, Parameters params){
        
        for(int i=0; i<inst.noPhys; i++){
            for(int iLoc=1; iLoc<=inst.noLocs; iLoc++){
                Physician phys = inst.physicians.get(i);
                if(phys.allowLoc[iLoc] && rnd.nextInt(100) <= params.probNPref){
                    inst.notPrefLoc.add(new NotPrefLoc(i+1,iLoc,1));
                }
            }
        }
    }
    
    public void createInst_requirements(Instance inst, Parameters params){
        
        inst.minAssign = new int[inst.noDays+1][5][inst.noLocs+1];
        inst.maxAssign = new int[inst.noDays+1][5][inst.noLocs+1];
        
        for(int iWD=1; iWD<=inst.noDays; iWD++){
            
            for(int iShift=1; iShift<=4; iShift++){ //MOR, AFT, NIG, DAY
                for(int iLoc=1; iLoc<=inst.noLocs; iLoc++){
                    inst.noRequirements++;

                    int minReq = 0;
                    int maxReq = 0;

                    if(inst.isWorkDay(iWD)){
                        int maxReqPerDSA = (int) Math.floor(inst.noPhys/(3*inst.noLocs));
                        
                        minReq = (int) Math.round(maxReqPerDSA*params.percMin_wD);
                        maxReq = Math.min(maxReqPerDSA,Math.round(minReq+minReq/2));
                    }
                    else{
                        int maxReqPerDSA = (int) Math.floor(inst.noPhys/(2*inst.noLocs));
                        
                        minReq = (int) Math.round(maxReqPerDSA*params.percMin_wD/2);
                        maxReq = Math.min(maxReqPerDSA,Math.round(minReq+minReq/2));
                    }

                    inst.minAssign[iWD][iShift][iLoc] = minReq;
                    inst.maxAssign[iWD][iShift][iLoc] = maxReq;
                }
            }
        }
    }
    
}
