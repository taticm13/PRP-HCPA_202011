/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package random;

import data.Instance;
import java.io.File;
import java.util.ArrayList;
import java.util.Calendar;

/** INFORMATION ABOUT THE INSTANCE GENERATOR
 * Author:      Tatiana Costa Meister
 * Last Update: May 17th, 2020
 * Version:     0.6
 */
public class Main {
    
    public static void main(String[] args) {
        
        String rootPath         = "Instances\\";
        String versionInstGen   = "0.6";
        String groupGen         = "12";
        
        String infoGen = "# RANDOM GENERATION (Version "+versionInstGen+") - "+currentDateHour()+"\n";
        
        String folder = rootPath+"Group "+groupGen+"\\";
        new File(folder).mkdir();
        
        int list_noPhys[] = new int[]{50,100,150,250,500};
        int list_noLocs[] = new int[]{4};
        int list_months[] = new int[]{1};
        
        ArrayList<Parameters> listParam = new ArrayList<>();
            for(int i=1; i<=3; i++){
                listParam.add(new Parameters("BD",10,20,i));
                listParam.add(new Parameters("MD",45,10,i));
                listParam.add(new Parameters("AD",90,0,i));
            }

        Generator generator = new Generator();

        for(int noPhys : list_noPhys){
            for(int noLocs : list_noLocs){
                for(int iMonth : list_months){
                    for(Parameters param : listParam){

                        param.month = iMonth;
                        param.year  = 2020;

                        param.noPhys = noPhys;
                        param.noLocs = noLocs;

                        Instance inst = generator.createInstance(param);

                        String nameInst = "I_"+param.group+"_"+noPhys+"P_"+noLocs+"L_ID"+param.ID+".txt";
                        new WriteFile(inst,folder+nameInst,param.printParameters(infoGen));
                        System.out.println("Created instance: "+nameInst);
                    }
                }
            }
        }
    }
    
    
    private static String currentDateHour(){
        Calendar today = Calendar.getInstance();
        
        String gerYear = Integer.toString(today.get(Calendar.YEAR));
        
        String gerMonth = Integer.toString(today.get(Calendar.MONTH)+1);
        if(gerMonth.length()==1) gerMonth = "0"+gerMonth;
        
        String gerDay = Integer.toString(today.get(Calendar.DAY_OF_MONTH));
        
        String gerHour = Integer.toString(today.get(Calendar.HOUR_OF_DAY));
        if(gerHour.length()==1) gerHour = "0"+gerHour;
        
        String gerMinute = Integer.toString(today.get(Calendar.MINUTE));
        if(gerMinute.length()==1) gerMinute = "0"+gerMinute;
 
        String gerSecond = Integer.toString(today.get(Calendar.SECOND));
        if(gerSecond.length()==1) gerSecond = "0"+gerSecond;
        
        return gerYear+"-"+gerMonth+"-"+gerDay+"_"+gerHour+"h"+gerMinute+"m"+gerSecond+"s";
    }
}
