/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package random;

/**
 *
 * @author Tatiana
 */


public class Parameters {
    
    public int noPhys;
    public int noLocs;
    public int year;
    public int month;
    public String group;
    public int percMin;
    public int percLock;
    
    public int ID;
    
    public Parameters(String info_group, int info_percMin, int info_percLock, int info_ID){
         
        group       = info_group;
        percMin     = info_percMin;
        percLock    = info_percLock;
        ID          = info_ID;
       
        setWorkload();
        set_allowLoc();
        set_nPref();
        
        set_requirements(percMin);        
        set_lock(percLock,false);
        set_fixed(00);
        
    }
    
/*  ## WORKLOAD ############################################################# */
    public int workload_percFullTime;    //200 hours and 48 ideal non business days
    public int workload_percParcial;     //120 hours and 24 ideal non business days    
    public void setWorkload(){
        workload_percFullTime   = 80;
        workload_percParcial    = 20;
    }
    
    
/*  ## ALLOWED LOCATIONS #################################################### */
    public int allowLoc_percUnrLocs;
    public int allowLoc_percPhysPerm;    
    public void set_allowLoc(){
        allowLoc_percUnrLocs    = 100;
        allowLoc_percPhysPerm   = 40;
    }
    
    
/*  ## DAY/SHIFT AND LOCATION NON PREFERENTIAL ############################## */
    public int probNPref;    
    public void set_nPref(){
        probNPref = 30;
    }
    
/*  ## LOCK ################################################################# */
    public int lock_probLockDS;
    public boolean lock_allDay;
    public int lock_max;
    
    public void set_lock(int probLock, boolean allDay){
        lock_probLockDS     = probLock;
        lock_allDay         = allDay;
        lock_max            = 0;
    }
    
    
/*  ## FIXED ################################################################# */
    public int fixed_prob;   
    public void set_fixed(int prob){
        fixed_prob = prob;
    }
    
      
/*  ## REQUIREMENTS ######################################################### */
    public double percMin_wD;
    public double percMin_nwD;   
    public void set_requirements(double percMin){
        percMin_wD = percMin/100;
        percMin_nwD = percMin/100/2;
    }
    
    public String printParameters(String version){
        String info = "";
        
        info += version+"\n";
        
        info += "# HOLIDAYS: National and regional holidays\n\n";
        
        info += "# CONTRACTS: \n";
        info += "# "+workload_percFullTime+"% of the physicians with FULL TIME workload (200 hours, 48h ideal not business days)\n";
        info += "# "+workload_percParcial +"% of the physicians with PARTIAL workload   (150 hours, 24h ideal not business days)\n\n";
        
        info += "# ALLOWED LOCATIONS: \n";
        info += "# "+allowLoc_percUnrLocs+"% of locations are unrestricted\n";
        info += "# "+allowLoc_percPhysPerm+"% probability of physician having authorization in restricted location\n\n";
        
        info += "# NON PREFERENTIAL:\n";
        info += "# "+probNPref+"% probability of a day/shift being non-preferential\n";
        info += "# "+probNPref+"% probability of a location being non-preferential\n\n";
        
        info += "# REQUIREMENTS:\n";
        info += "# Minimum on working days = noPhys/(3*noLocs)*"+percMin_wD+"\n";
        info += "# Minimum on non-working days = noPhys/(2*noLocs)*"+percMin_nwD+"\n";
        info += "# Maximum = min + min/2\n\n";
                
        info += "# LOCK ASSIGNMENTS:\n";
        info += "# "+lock_probLockDS+"% probability of a physician having a lock on the day/shift\n";
        info += "# It locks all shifts of the same day = "+lock_allDay+"\n\n";
        
        info += "# FIXED ASSIGNMENTS:\n";
        info += "# "+fixed_prob+"% probability of an assignments being fixed \n\n";
        
        return info;
    }
}
